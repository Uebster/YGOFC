using UnityEngine;
using System.Collections.Generic;

public partial class CardEffectManager
{
    // =========================================================================================
    // IMPLEMENTAÇÃO ESPECÍFICA (ID 1001 - 1100)
    // =========================================================================================

    void Effect_1001_KangarooChamp(CardDisplay source)
    {
        // Effect: If this card attacks or is attacked, change it to Defense Position at the end of the Damage Step.
        // Lógica implementada no OnBattleEnd.
    }

    void Effect_1004_KarakuriSpider(CardDisplay source)
    {
        // Effect: If this card attacks a DARK monster, destroy that monster.
        // Lógica implementada no OnDamageCalculation.
    }

    void Effect_1005_KarateMan(CardDisplay source)
    {
        if (source.isOnField)
        {
            source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Temporary, StatModifier.Operation.Set, source.originalAtk * 2, source));
            source.scheduledForDestruction = true;
            Debug.Log("Karate Man: ATK dobrado. Será destruído na End Phase.");
        }
    }

    void Effect_1008_Kazejin(CardDisplay source)
    {
        // Effect: Once while face-up, make attacking monster's ATK 0 during damage calculation.
        // Lógica implementada no OnDamageCalculation.
    }

    void Effect_1009_Kelbek(CardDisplay source)
    {
        // Effect: If attacked, return attacking monster to hand.
        // Lógica implementada no OnBattleEnd.
    }

    void Effect_1010_Keldo(CardDisplay source)
    {
        // Effect: When sent to GY by battle: Select 2 cards in opp GY, shuffle into Deck.
        // Lógica implementada no OnCardSentToGraveyard.
    }

    void Effect_1014_KingDragun(CardDisplay source)
    {
        // Effect: Your Dragons cannot be targeted by Spell/Trap/Effects. Once per turn: SS 1 Dragon from hand.
        if (source.isOnField)
        {
            List<CardData> hand = GameManager.Instance.GetPlayerHandData();
            List<CardData> dragons = hand.FindAll(c => c.race == "Dragon" && c.type.Contains("Monster"));
            
            if (dragons.Count > 0)
            {
                GameManager.Instance.OpenCardSelection(dragons, "Invocar Dragão", (selected) => {
                    GameManager.Instance.SpecialSummonFromData(selected, source.isPlayerCard);
                    GameManager.Instance.RemoveCardFromHand(selected, source.isPlayerCard);
                });
            }
        }
    }

    void Effect_1016_KingTigerWanghu(CardDisplay source)
    {
        // Effect: When monster with ATK <= 1400 is Summoned, destroy it.
        // Lógica implementada no OnSummonImpl.
    }

    void Effect_1018_KingOfTheSkullServants(CardDisplay source)
    {
        // Effect: ATK = Skull Servants/King of Skull Servants in GY * 1000. Revive by banishing 1 Skull Servant.
        if (source.isOnField)
        {
            // Lógica de ATK
            int count = 0;
            List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
            count += gy.FindAll(c => c.name == "Skull Servant" || c.name == "King of the Skull Servants").Count;
            
            source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Set, count * 1000, source));
        }
        else if (source.isInPile) // No GY
        {
            // Lógica de Revive (Simplificado: Trigger manual do GY não é suportado nativamente, seria um efeito de ignição se estivesse na mão ou campo, mas aqui é GY trigger)
            // Vamos simular como se fosse ativado ao ser destruído
            Debug.Log("King of the Skull Servants: Efeito de reviver (Requer sistema de efeitos no GY).");
        }
    }

    void Effect_1019_KingOfTheSwamp(CardDisplay source)
    {
        // Effect: Discard to add Polymerization. Substitute for Fusion Material.
        if (!source.isOnField) // Da mão
        {
            GameManager.Instance.DiscardCard(source);
            Effect_SearchDeck(source, "Polymerization");
        }
    }

    void Effect_1020_KingsKnight(CardDisplay source)
    {
        // Effect: If Queen's Knight on field when Normal Summoned: SS Jack's Knight from Deck.
        if (GameManager.Instance.IsCardActiveOnField("Queen's Knight") || GameManager.Instance.IsCardActiveOnField("1475")) // ID Queen's Knight
        {
            Effect_SearchDeck(source, "Jack's Knight", "Monster"); // Simplificado para busca/SS
        }
    }

    void Effect_1021_Kiryu(CardDisplay source)
    {
        if (source.isOnField && source.CurrentCardData.property == "Equip")
        {
             if (SpellTrapManager.Instance != null)
             {
                 SpellTrapManager.Instance.StartTargetSelection(
                     (t) => t.isOnField && !t.isPlayerCard && t.CurrentCardData.type.Contains("Monster") && !t.isFlipped,
                     (target) => {
                         GameManager.Instance.SendToGraveyard(source.CurrentCardData, source.isPlayerCard);
                         Destroy(source.gameObject);
                         
                         if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(target);
                         GameManager.Instance.SendToGraveyard(target.CurrentCardData, target.isPlayerCard);
                         Destroy(target.gameObject);
                     }
                 );
             }
        }
        else
        {
            Effect_Union(source, "Dark Blade", 900, 0);
        }
    }

    void Effect_1022_Kiseitai(CardDisplay source)
    {
        // Effect: If attacked face-down, equip to attacker. Gain LP equal to half attacker's ATK each Standby.
        // Lógica implementada no BattleManager e OnPhaseStart.
    }

    void Effect_1023_KishidoSpirit(CardDisplay source)
    {
        // Effect: Monsters not destroyed by battle if ATK is equal.
        // Lógica implementada no BattleManager.
    }

    void Effect_1024_KnightsTitle(CardDisplay source)
    {
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.name == "Dark Magician",
                (t) => {
                    GameManager.Instance.TributeCard(t);
                    Effect_SpecialSummonFromDeck(source, nameContains: "Dark Magician Knight");
                }
            );
        }
    }

    void Effect_1025_Koitsu(CardDisplay source)
    {
        // Effect: Union for Aitsu. +3000 ATK. Piercing.
        Effect_Union(source, "Aitsu", 3000, 0);
    }

    void Effect_1028_Kotodama(CardDisplay source)
    {
        // Effect: As long as this card remains face-up on the field, monsters with the same name cannot exist on the field.
        // If a monster with the same name is Summoned, it is destroyed.
        // Lógica implementada no OnSummonImpl.
    }

    void Effect_1031_KozakysSelfDestructButton(CardDisplay source)
    {
        // Effect: When "Kozaky" is destroyed and sent to the Graveyard, inflict 1000 damage to the controller of this card.
        // Lógica implementada no OnCardSentToGraveyard.
    }

    void Effect_1033_Kryuel(CardDisplay source)
    {
        // Effect: When sent to GY by battle: Toss coin. Heads: Destroy opponent's monster.
        Effect_CoinTossDestroy(source, 1, 1, TargetType.Monster);
    }

    void Effect_1035_KunaiWithChain(CardDisplay source)
    {
        // Effect: Activate 1 or both:
        // 1. Change attacking monster to Defense.
        // 2. Equip to a monster, +500 ATK.
        if (BattleManager.Instance != null && BattleManager.Instance.currentAttacker != null)
        {
            BattleManager.Instance.currentAttacker.ChangePosition();
            Debug.Log("Kunai with Chain: Atacante virou defesa.");
        }
        else
        {
            Effect_Equip(source, 500, 0);
        }
    }

    void Effect_1037_Kuriboh(CardDisplay source)
    {
        // Effect: Discard to make battle damage 0.
        // Lógica implementada no OnDamageCalculation.
        if (!source.isOnField) // Da mão
        {
            GameManager.Instance.DiscardCard(source);
            if (BattleManager.Instance != null) BattleManager.Instance.noBattleDamageThisTurn = true;
            Debug.Log("Kuriboh: Dano de batalha reduzido a 0 (Efeito ativado da mão).");
        }
    }

    void Effect_1040_KycooTheGhostDestroyer(CardDisplay source)
    {
        // Effect: When inflicts battle damage, banish 2 from opp GY. Opp cannot banish from GYs.
        // Banish logic in OnDamageDealtImpl.
        Debug.Log("Kycoo the Ghost Destroyer: Efeitos passivos de batalha e bloqueio de GY ativos.");
    }

    void Effect_1046_LabyrinthOfNightmare(CardDisplay source)
    {
        // Effect: End Phase: Change battle position of all face-up monsters.
        // Lógica implementada no OnPhaseStart.
    }

    void Effect_1047_LadyAssailantOfFlames(CardDisplay source)
    {
        List<CardData> deck = source.isPlayerCard ? GameManager.Instance.GetPlayerMainDeck() : GameManager.Instance.GetOpponentMainDeck();
        int count = Mathf.Min(3, deck.Count);
        for (int i = 0; i < count; i++)
        {
            CardData c = deck[0];
            deck.RemoveAt(0);
            GameManager.Instance.RemoveFromPlay(c, source.isPlayerCard);
        }
        Effect_DirectDamage(source, 800);
    }

    void Effect_1048_LadyNinjaYae(CardDisplay source)
    {
        // Effect: Discard 1 WIND monster; return all S/T opponent controls to hand.
        List<CardData> hand = GameManager.Instance.GetPlayerHandData();
        List<CardData> winds = hand.FindAll(c => c.attribute == "Wind" && c.type.Contains("Monster"));
        
        if (winds.Count > 0)
        {
            GameManager.Instance.OpenCardSelection(winds, "Descarte 1 WIND", (discarded) => {
                GameManager.Instance.DiscardCard(GameManager.Instance.playerHand.Find(g => g.GetComponent<CardDisplay>().CurrentCardData == discarded).GetComponent<CardDisplay>());
                
                List<CardDisplay> toReturn = new List<CardDisplay>();
                if (GameManager.Instance.duelFieldUI != null)
                {
                    CollectCards(GameManager.Instance.duelFieldUI.opponentSpellZones, toReturn);
                    CollectCards(new Transform[] { GameManager.Instance.duelFieldUI.opponentFieldSpell }, toReturn);
                }
                foreach(var c in toReturn) GameManager.Instance.ReturnToHand(c);
                Debug.Log("Lady Ninja Yae: S/T retornadas.");
            });
        }
    }

    void Effect_1049_LadyPanther(CardDisplay source)
    {
        // Effect: Tribute this card; return 1 monster destroyed by battle this turn to top of Deck.
        if (source.isOnField)
        {
            GameManager.Instance.TributeCard(source);
            List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
            List<CardData> monsters = gy.FindAll(c => c.type.Contains("Monster"));
            if (monsters.Count > 0)
            {
                GameManager.Instance.OpenCardSelection(monsters, "Retornar ao Topo", (selected) => {
                    gy.Remove(selected);
                    GameManager.Instance.GetPlayerMainDeck().Insert(0, selected);
                });
            }
        }
    }

    void Effect_1051_LarvaeMoth(CardDisplay source)
    {
        // Effect: SS from hand by Tributing Petit Moth equipped with Cocoon for 2 turns.
        if (!source.isOnField)
        {
            if (SpellTrapManager.Instance != null) {
                 SpellTrapManager.Instance.StartTargetSelection(
                     (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.name == "Petit Moth" && CardEffectManager.Instance.GetEquippedCards(t).Exists(e => e.CurrentCardData.name == "Cocoon of Evolution" && e.turnCounter >= 2),
                     (t) => {
                         GameManager.Instance.TributeCard(t);
                         GameManager.Instance.SpecialSummonFromData(source.CurrentCardData, source.isPlayerCard);
                         GameManager.Instance.RemoveCardFromHand(source.CurrentCardData, source.isPlayerCard);
                     }
                 );
             }
        }
    }

    void Effect_1053_LaserCannonArmor(CardDisplay source)
    {
        Effect_Equip(source, 300, 300, "Insect");
    }

    void Effect_1054_LastDayOfWitch(CardDisplay source)
    {
        Effect_DestroyType(source, "Spellcaster");
    }

    void Effect_1055_LastTurn(CardDisplay source)
    {
        // Effect: Win condition complexa.
        if (GameManager.Instance.playerLP <= 1000)
        {
            if (SpellTrapManager.Instance != null)
            {
                SpellTrapManager.Instance.StartTargetSelection(
                    (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.type.Contains("Monster"),
                    (target) => {
                        List<CardDisplay> toDestroy = new List<CardDisplay>();
                        if (GameManager.Instance.duelFieldUI != null)
                        {
                            CollectCards(GameManager.Instance.duelFieldUI.playerMonsterZones, toDestroy);
                            CollectCards(GameManager.Instance.duelFieldUI.opponentMonsterZones, toDestroy);
                            CollectCards(GameManager.Instance.duelFieldUI.playerSpellZones, toDestroy);
                            CollectCards(GameManager.Instance.duelFieldUI.opponentSpellZones, toDestroy);
                        }
                        toDestroy.Remove(target);
                        DestroyCards(toDestroy, source.isPlayerCard);
                        Debug.Log("Last Turn: Condição de vitória alternativa ativada.");
                    }
                );
            }
        }
    }

    void Effect_1056_LastWill(CardDisplay source)
    {
        CardEffectManager.Instance.lastWillActive = true;
        Debug.Log("Last Will: Efeito ativo.");
    }

    void Effect_1059_LavaBattleguard(CardDisplay source)
    {
        // Effect: +500 ATK for each Swamp Battleguard.
        int count = 0;
        if (GameManager.Instance.IsCardActiveOnField("Swamp Battleguard") || GameManager.Instance.IsCardActiveOnField("1799")) count++;
        source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, count * 500, source));
    }

    void Effect_1060_LavaGolem(CardDisplay source)
    {
        // Effect: SS to opponent's field by tributing 2 monsters. 1000 damage standby.
        // Condition: Cannot be Normal Summoned/Set. Must first be Special Summoned (from your hand) to your opponent's field by Tributing 2 monsters they control.
        if (!source.isOnField)
        {
            // Check if opponent has at least 2 monsters
            if (SummonManager.Instance.HasEnoughTributes(2, !source.isPlayerCard))
            {
                 List<CardDisplay> oppMonsters = new List<CardDisplay>();
                 if (GameManager.Instance.duelFieldUI != null)
                 {
                     foreach(var zone in GameManager.Instance.duelFieldUI.opponentMonsterZones)
                     {
                         if(zone.childCount > 0) oppMonsters.Add(zone.GetChild(0).GetComponent<CardDisplay>());
                     }
                 }
                 
                 if (oppMonsters.Count >= 2)
                 {
                     List<CardData> oppMonsterData = new List<CardData>();
                     foreach(var m in oppMonsters) oppMonsterData.Add(m.CurrentCardData);
                     
                     GameManager.Instance.OpenCardMultiSelection(oppMonsterData, "Tribute 2 Opponent Monsters", 2, 2, (selected) => {
                         // Tribute them
                         foreach(var cardData in selected)
                         {
                             CardDisplay cd = oppMonsters.Find(m => m.CurrentCardData == cardData);
                             if (cd != null) GameManager.Instance.TributeCard(cd);
                         }
                         
                         
                         GameManager.Instance.SpecialSummonFromData(source.CurrentCardData, !source.isPlayerCard, true, false); // Face-up Attack
                         GameManager.Instance.RemoveCardFromHand(source.CurrentCardData, source.isPlayerCard);
                         
                         Debug.Log("Lava Golem: Summoned to opponent's field.");
                     });
                 }
            }
            else
            {
                Debug.Log("Lava Golem: Opponent does not have 2 monsters.");
            }
        }
    }

    void Effect_1063_LegacyHunter(CardDisplay source)
    {
        // Effect: If destroys monster by battle: Opponent shuffles 1 random card from hand to Deck.
        // Lógica implementada no OnBattleEnd.
    }

    void Effect_1064_LegacyOfYataGarasu(CardDisplay source)
    {
        bool oppHasSpirit = false;
        if (GameManager.Instance.duelFieldUI != null) {
            Transform[] zones = source.isPlayerCard ? GameManager.Instance.duelFieldUI.opponentMonsterZones : GameManager.Instance.duelFieldUI.playerMonsterZones;
            foreach(var z in zones) {
                if (z.childCount > 0) {
                    var m = z.GetChild(0).GetComponent<CardDisplay>();
                    if (m != null && m.CurrentCardData.type.Contains("Spirit") && !m.isFlipped) oppHasSpirit = true;
                }
            }
        }
        GameManager.Instance.DrawCard();
        if (oppHasSpirit) GameManager.Instance.DrawCard();
    }

    void Effect_1065_LegendaryBlackBelt(CardDisplay source)
    {
        // Effect: Equip. If destroys monster by battle: Inflict damage = DEF of destroyed monster.
        // Lógica implementada no OnBattleEnd.
        Effect_Equip(source, 0, 0); // Apenas equipa
    }

    void Effect_1066_LegendaryFiend(CardDisplay source)
    {
        // Effect: Gains 700 ATK each Standby Phase.
        if (source.isOnField && source.position == CardDisplay.BattlePosition.Attack)
        {
            source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, 700, source));
            Debug.Log("Legendary Fiend: +700 ATK (Standby Phase).");
        }
    }

    void Effect_1067_LegendaryFlameLord(CardDisplay source)
    {
        // Ritual. Can put counter. Remove 3 counters -> Destroy all monsters.
        // Lógica de Spell Counter no OnSpellActivated
        if (SpellCounterManager.Instance.GetCount(source) >= 3)
        {
            SpellCounterManager.Instance.RemoveCounter(source, 3);
            DestroyAllMonsters(true, true); // Exceto ele mesmo (filtro pendente)
            Debug.Log("Legendary Flame Lord: Incinerator ativado!");
        }
    }

    void Effect_1068_LegendaryJujitsuMaster(CardDisplay source)
    {
        // Effect: If battled in Defense: Return attacker to top of Deck.
        // Lógica implementada no OnBattleEnd.
    }

    void Effect_1069_LegendarySword(CardDisplay source)
    {
        Effect_Equip(source, 300, 300, "Warrior");
    }

    void Effect_1070_Leghul(CardDisplay source)
    {
        source.canAttackDirectly = true;
    }

    void Effect_1071_Lekunga(CardDisplay source)
    {
        // Effect: Banish 2 WATER from GY; SS 1 Lekunga Token.
        List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
        List<CardData> waters = gy.FindAll(c => c.attribute == "Water");
        
        if (waters.Count >= 2)
        {
            GameManager.Instance.OpenCardMultiSelection(waters, "Banir 2 WATER", 2, 2, (selected) => {
                foreach(var c in selected)
                {
                    GameManager.Instance.RemoveFromPlay(c, source.isPlayerCard);
                    gy.Remove(c);
                }
                GameManager.Instance.SpawnToken(source.isPlayerCard, 700, 700, "Lekunga Token");
            });
        }
    }

    void Effect_1075_LesserFiend(CardDisplay source)
    {
        // Effect: Monsters destroyed by this card are banished instead of going to GY.
        // Lógica implementada no OnBattleEnd.
    }

    void Effect_1076_LevelConversionLab(CardDisplay source)
    {
        List<CardData> hand = GameManager.Instance.GetPlayerHandData();
        List<CardData> monsters = hand.FindAll(c => c.type.Contains("Monster"));
        
        if (monsters.Count > 0)
        {
            GameManager.Instance.OpenCardSelection(monsters, "Revelar Monstro", (selected) => {
                GameManager.Instance.TossCoin(1, (heads) => {
                    int roll = Random.Range(1, 7);
                    Debug.Log($"Level Conversion Lab: Rolou {roll}. Nível de {selected.name} alterado.");
                    selected.level = roll; // Caution: modifying global CardData
                });
            });
        }
    }

    void Effect_1077_LevelLimitAreaB(CardDisplay source)
    {
        // Effect: All Level 4 or higher monsters in Attack Position are changed to Defense Position.
        if (GameManager.Instance.duelFieldUI != null)
        {
            List<CardDisplay> all = new List<CardDisplay>();
            CollectMonsters(GameManager.Instance.duelFieldUI.playerMonsterZones, all);
            CollectMonsters(GameManager.Instance.duelFieldUI.opponentMonsterZones, all);
            
            foreach(var m in all)
            {
                if (m.CurrentCardData.level >= 4 && m.position == CardDisplay.BattlePosition.Attack)
                {
                    m.ChangePosition();
                }
            }
        }
    }

    void Effect_1078_LevelUp(CardDisplay source)
    {
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.name.Contains("LV"),
                (t) => {
                    string currentName = t.CurrentCardData.name;
                    GameManager.Instance.SendToGraveyard(t.CurrentCardData, true);
                    Destroy(t.gameObject);
                    
                    if (currentName.Contains("LV4")) Effect_SpecialSummonFromDeck(source, nameContains: currentName.Replace("LV4", "LV6"));
                    else if (currentName.Contains("LV6")) Effect_SpecialSummonFromDeck(source, nameContains: currentName.Replace("LV6", "LV8"));
                    else if (currentName.Contains("LV3")) Effect_SpecialSummonFromDeck(source, nameContains: currentName.Replace("LV3", "LV5"));
                    else if (currentName.Contains("LV5")) Effect_SpecialSummonFromDeck(source, nameContains: currentName.Replace("LV5", "LV7"));
                }
            );
        }
    }

    void Effect_1079_LeviaDragonDaedalus(CardDisplay source)
    {
        if (GameManager.Instance.IsCardActiveOnField("2015") || GameManager.Instance.IsCardActiveOnField("0013")) // Umi
        {
            Transform fieldZone = source.isPlayerCard ? GameManager.Instance.duelFieldUI.playerFieldSpell : GameManager.Instance.duelFieldUI.opponentFieldSpell;
            if (fieldZone.childCount > 0) {
                var umi = fieldZone.GetChild(0).GetComponent<CardDisplay>();
                GameManager.Instance.SendToGraveyard(umi.CurrentCardData, umi.isPlayerCard);
                Destroy(umi.gameObject);
            }

            List<CardDisplay> toDestroy = new List<CardDisplay>();
            if (GameManager.Instance.duelFieldUI != null)
            {
                CollectCards(GameManager.Instance.duelFieldUI.playerMonsterZones, toDestroy);
                CollectCards(GameManager.Instance.duelFieldUI.opponentMonsterZones, toDestroy);
                CollectCards(GameManager.Instance.duelFieldUI.playerSpellZones, toDestroy);
                CollectCards(GameManager.Instance.duelFieldUI.opponentSpellZones, toDestroy);
            }
            toDestroy.Remove(source);
            DestroyCards(toDestroy, source.isPlayerCard);
        }
    }

    void Effect_1080_LifeAbsorbingMachine(CardDisplay source)
    {
        // Effect: Standby Phase: Gain LP equal to half the LP you paid in the last turn.
        // Requires tracking. For now, just log.
        Debug.Log("Life Absorbing Machine: Recuperação de LP (Requer sistema de rastreamento de LP pagos).");
    }

    void Effect_1081_LightOfIntervention(CardDisplay source)
    {
        Debug.Log("Light of Intervention: Monstros devem ser invocados face-up (Tratado no GameManager).");
    }

    void Effect_1082_LightOfJudgment(CardDisplay source)
    {
        // Effect: If "The Sanctuary in the Sky" is on field: Discard 1 LIGHT; look at opp hand discard 1 OR destroy 1 card opp controls.
        if (GameManager.Instance.IsCardActiveOnField("1887")) // Sanctuary
        {
            List<CardData> hand = GameManager.Instance.GetPlayerHandData();
            List<CardData> lights = hand.FindAll(c => c.attribute == "Light" && c.type.Contains("Monster"));
            
            if (lights.Count > 0)
            {
                GameManager.Instance.OpenCardSelection(lights, "Descarte 1 LIGHT", (discarded) => {
                    GameManager.Instance.DiscardCard(GameManager.Instance.playerHand.Find(g => g.GetComponent<CardDisplay>().CurrentCardData == discarded).GetComponent<CardDisplay>());
                    
                    if (SpellTrapManager.Instance != null)
                    {
                        SpellTrapManager.Instance.StartTargetSelection(
                            (t) => t.isOnField && !t.isPlayerCard,
                            (t) => {
                                GameManager.Instance.SendToGraveyard(t.CurrentCardData, t.isPlayerCard);
                                Destroy(t.gameObject);
                            }
                        );
                    }
                });
            }
        }
    }

    void Effect_1083_LightenTheLoad(CardDisplay source)
    {
        // Effect: Shuffle 1 Level 7+ monster from hand to Deck; draw 1 card.
        List<CardData> hand = GameManager.Instance.GetPlayerHandData();
        List<CardData> highLevel = hand.FindAll(c => c.level >= 7 && c.type.Contains("Monster"));
        
        if (highLevel.Count > 0)
        {
            GameManager.Instance.OpenCardSelection(highLevel, "Embaralhar no Deck", (selected) => {
                GameManager.Instance.RemoveCardFromHand(selected, true);
                GameManager.Instance.GetPlayerMainDeck().Add(selected);
                GameManager.Instance.ShuffleDeck(true);
                GameManager.Instance.DrawCard();
            });
        }
    }

    void Effect_1084_LightforceSword(CardDisplay source)
    {
        // Effect: Banish 1 random card from opp hand face-down for 4 turns.
        GameManager.Instance.DiscardRandomHand(false, 1); // Deveria ser banish temporário
        Debug.Log("Lightforce Sword: Carta banida da mão do oponente.");
    }

    void Effect_1085_LightningBlade(CardDisplay source)
    {
        Effect_Equip(source, 800, 0, "Warrior");
    }

    void Effect_1087_LightningVortex(CardDisplay source)
    {
        // Effect: Discard 1 card; destroy all face-up monsters opponent controls.
        List<CardData> hand = GameManager.Instance.GetPlayerHandData();
        if (hand.Count > 0)
        {
            GameManager.Instance.OpenCardSelection(hand, "Descarte 1 carta", (discarded) => {
                GameManager.Instance.DiscardCard(GameManager.Instance.playerHand.Find(g => g.GetComponent<CardDisplay>().CurrentCardData == discarded).GetComponent<CardDisplay>());
                Debug.Log("Lightning Vortex: Destruindo monstros face-up do oponente.");
                
                List<CardDisplay> toDestroy = new List<CardDisplay>();
                if (GameManager.Instance.duelFieldUI != null)
                {
                    foreach(var z in GameManager.Instance.duelFieldUI.opponentMonsterZones)
                    {
                        if(z.childCount > 0)
                        {
                            var m = z.GetChild(0).GetComponent<CardDisplay>();
                            if(m != null && !m.isFlipped) toDestroy.Add(m);
                        }
                    }
                }
                DestroyCards(toDestroy, false);
            });
        }
    }

    void Effect_1088_LimiterRemoval(CardDisplay source)
    {
        // Effect: Double ATK of all Machines. Destroy them at End Phase.
        if (GameManager.Instance.duelFieldUI != null)
        {
            List<CardDisplay> machines = new List<CardDisplay>();
            foreach(var z in GameManager.Instance.duelFieldUI.playerMonsterZones)
            {
                if(z.childCount > 0)
                {
                    var m = z.GetChild(0).GetComponent<CardDisplay>();
                    if(m != null && m.CurrentCardData.race == "Machine")
                    {
                        m.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Temporary, 2f, source));
                    m.scheduledForDestruction = true;
                    Debug.Log($"Limiter Removal: {m.CurrentCardData.name} ATK dobrado. Será destruído na End Phase.");
                    }
                }
            }
        }
    }

    void Effect_1091_LittleChimera(CardDisplay source)
    {
        Effect_Field(source, 500, -400, "", "Fire");
    }

    void Effect_1093_LittleWinguard(CardDisplay source)
    {
        // Effect: Once per turn, during End Phase: Change battle position.
        // This is a trigger effect.
        Debug.Log("Little-Winguard: Pode mudar posição na End Phase.");
    }

    void Effect_1096_LoneWolf(CardDisplay source)
    {
        // Effect: If you control "Monk Fighter" or "Master Monk", it cannot be destroyed by battle.
        Debug.Log("Lone Wolf: Proteção ativa (Passivo).");
    }

    void Effect_1097_LordPoison(CardDisplay source)
    {
        // Effect: If destroyed by battle: SS 1 Plant from GY.
        List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
        List<CardData> plants = gy.FindAll(c => c.race == "Plant" && c != source.CurrentCardData);
        
        if (plants.Count > 0)
        {
            GameManager.Instance.OpenCardSelection(plants, "Reviver Planta", (selected) => {
                GameManager.Instance.SpecialSummonFromData(selected, source.isPlayerCard);
            });
        }
    }

    void Effect_1098_LordOfD(CardDisplay source)
    {
        // Effect: Dragons cannot be targeted by card effects.
        Debug.Log("Lord of D.: Proteção de Dragões ativa (Passivo).");
    }

    void Effect_1101_LostGuardian(CardDisplay source)
    {
        // Effect: DEF = 700 * banished Rocks.
        if (source.isOnField)
        {
            int count = 0;
            // Count banished rocks (assuming we can access banished list)
            List<CardData> banished = GameManager.Instance.GetPlayerRemoved();
            count = banished.FindAll(c => c.race == "Rock").Count;
            
            source.AddStatModifier(new StatModifier(StatModifier.StatType.DEF, StatModifier.ModifierType.Continuous, StatModifier.Operation.Set, count * 700, source));
        }
    }

    void Effect_1103_LuminousSoldier(CardDisplay source)
    {
        // Effect: If attacks DARK, +500 ATK.
        Debug.Log("Luminous Soldier: Buff vs DARK (OnDamageCalculation).");
    }

    void Effect_1104_LuminousSpark(CardDisplay source)
    {
        Effect_Field(source, 500, -400, "", "Light");
    }

    void Effect_1112_MachineConversionFactory(CardDisplay source)
    {
        Effect_Equip(source, 300, 300, "Machine");
    }

    void Effect_1113_MachineDuplication(CardDisplay source)
    {
        // Effect: Select 1 Machine with ATK <= 500; SS up to 2 copies from Deck.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.race == "Machine" && t.currentAtk <= 500,
                (target) => {
                    string name = target.CurrentCardData.name;
                    List<CardData> deck = GameManager.Instance.GetPlayerMainDeck();
                    List<CardData> copies = deck.FindAll(c => c.name == name);
                    
                    if (copies.Count > 0)
                    {
                        int max = Mathf.Min(2, copies.Count);
                        GameManager.Instance.OpenCardMultiSelection(copies, "Invocar Cópias", 1, max, (selected) => {
                            foreach(var c in selected)
                            {
                                GameManager.Instance.SpecialSummonFromData(c, source.isPlayerCard);
                                deck.Remove(c);
                            }
                            GameManager.Instance.ShuffleDeck(source.isPlayerCard);
                        });
                    }
                }
            );
        }
    }

    void Effect_1114_MachineKing(CardDisplay source)
    {
        // Effect: +100 ATK for each Machine on the field.
        int count = 0;
        if (GameManager.Instance.duelFieldUI != null)
        {
            List<CardDisplay> all = new List<CardDisplay>();
            CollectMonsters(GameManager.Instance.duelFieldUI.playerMonsterZones, all);
            CollectMonsters(GameManager.Instance.duelFieldUI.opponentMonsterZones, all);
            foreach(var m in all) if (m.CurrentCardData.race == "Machine") count++;
        }
        source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, count * 100, source));
    }

    void Effect_1117_MadSwordBeast(CardDisplay source)
    {
        // Effect: Piercing damage.
        Debug.Log("Mad Sword Beast: Dano perfurante (Passivo).");
    }

    void Effect_1121_MagicDrain(CardDisplay source)
    {
        var link = GetLinkToNegate(source);
        if (link != null && link.cardSource.CurrentCardData.type.Contains("Spell"))
        {
            bool oppIsPlayer = link.cardSource.isPlayerCard;
            List<CardData> oppHand = oppIsPlayer ? GameManager.Instance.GetPlayerHandData() : GameManager.Instance.GetOpponentHandData();
            List<CardData> spells = oppHand.FindAll(c => c.type.Contains("Spell"));

            if (spells.Count > 0)
            {
                if (oppIsPlayer && UIManager.Instance != null) {
                    UIManager.Instance.ShowConfirmation("Magic Drain ativada! Descartar 1 Magia para negar?", () => {
                        GameManager.Instance.OpenCardSelection(spells, "Descarte 1 Magia", (discarded) => {
                            GameManager.Instance.DiscardCard(GameManager.Instance.playerHand.Find(g => g.GetComponent<CardDisplay>().CurrentCardData == discarded).GetComponent<CardDisplay>());
                            Debug.Log("Magic Drain: Oponente descartou magia. Efeito de Magic Drain negado!");
                        });
                    }, () => { NegateAndDestroy(source, link); });
                }
                else {
                    if (Random.value > 0.5f) { // IA: 50% de chance de descartar
                        CardData discarded = spells[Random.Range(0, spells.Count)];
                        GameManager.Instance.DiscardCard(GameManager.Instance.opponentHand.Find(g => g.GetComponent<CardDisplay>().CurrentCardData == discarded).GetComponent<CardDisplay>(), false);
                        Debug.Log("Magic Drain: IA descartou magia. Efeito negado!");
                    } else { NegateAndDestroy(source, link); }
                }
            }
            else
            {
                NegateAndDestroy(source, link);
            }
        }
    }

    void Effect_1122_MagicFormula(CardDisplay source)
    {
        // Effect: Equip "Dark Magician" or "Dark Magician Girl". +700 ATK. If sent to GY, gain 1000 LP.
        Effect_Equip(source, 700, 0, "Spellcaster"); // Simplificado
        // Lógica de cura no OnCardSentToGraveyard
    }

    void Effect_1123_MagicJammer(CardDisplay source)
    {
        // Effect: Discard 1 card; negate Spell activation and destroy it.
        var link = GetLinkToNegate(source);
        if (link != null && link.cardSource.CurrentCardData.type.Contains("Spell"))
        {
            List<CardData> hand = GameManager.Instance.GetPlayerHandData();
            if (hand.Count > 0)
            {
                GameManager.Instance.OpenCardSelection(hand, "Descarte 1 carta", (discarded) => {
                    GameManager.Instance.DiscardCard(GameManager.Instance.playerHand.Find(g => g.GetComponent<CardDisplay>().CurrentCardData == discarded).GetComponent<CardDisplay>());
                    NegateAndDestroy(source, link);
                });
            }
        }
    }

    void Effect_1124_MagicReflector(CardDisplay source)
    {
        // Effect: Select 1 Spell Card; place 1 counter on it. If destroyed, remove counter instead.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.CurrentCardData.type.Contains("Spell"),
                (t) => {
                    t.AddSpellCounter(1);
                    SpellCounterManager.Instance.AddCounter(t, 1);
                    Debug.Log($"Magic Reflector: Contador adicionado em {t.CurrentCardData.name}.");
                }
            );
        }
    }

    void Effect_1125_MagicalArmShield(CardDisplay source)
    {
        // Effect: When attacked: Take control of 1 opp monster (except attacker) and make it the target.
        if (BattleManager.Instance != null && BattleManager.Instance.currentAttacker != null)
        {
            if (SpellTrapManager.Instance != null)
            {
                SpellTrapManager.Instance.StartTargetSelection(
                    (t) => t.isOnField && !t.isPlayerCard && t != BattleManager.Instance.currentAttacker,
                    (newTarget) => {
                        GameManager.Instance.SwitchControl(newTarget);
                        BattleManager.Instance.currentTarget = newTarget;
                        Debug.Log($"Magical Arm Shield: {newTarget.CurrentCardData.name} é o novo alvo.");
                    }
                );
            }
        }
    }

    void Effect_1126_MagicalDimension(CardDisplay source)
    {
        // Effect: If you control Spellcaster: Tribute 1 monster; SS Spellcaster from hand, then destroy 1 monster.
        if (GameManager.Instance.IsCardActiveOnField("Spellcaster") || GameManager.Instance.IsCardActiveOnField("0419")) // Check Spellcaster generic
        {
            if (SpellTrapManager.Instance != null)
            {
                SpellTrapManager.Instance.StartTargetSelection(
                    (t) => t.isOnField && t.isPlayerCard,
                    (tribute) => {
                        GameManager.Instance.TributeCard(tribute);
                        
                        List<CardData> hand = GameManager.Instance.GetPlayerHandData();
                        List<CardData> spellcasters = hand.FindAll(c => c.race == "Spellcaster" && c.type.Contains("Monster"));
                        
                        if (spellcasters.Count > 0)
                        {
                            GameManager.Instance.OpenCardSelection(spellcasters, "Invocar Mago", (selected) => {
                                GameManager.Instance.SpecialSummonFromData(selected, source.isPlayerCard);
                                GameManager.Instance.RemoveCardFromHand(selected, source.isPlayerCard);
                                
                                // Optional Destroy
                                UIManager.Instance.ShowConfirmation("Destruir um monstro?", () => {
                                    SpellTrapManager.Instance.StartTargetSelection(
                                        (target) => target.isOnField && target.CurrentCardData.type.Contains("Monster"),
                                        (target) => {
                                            GameManager.Instance.SendToGraveyard(target.CurrentCardData, target.isPlayerCard);
                                            Destroy(target.gameObject);
                                        }
                                    );
                                });
                            });
                        }
                    }
                );
            }
        }
    }

    void Effect_1127_MagicalExplosion(CardDisplay source)
    {
        // Effect: If no cards in hand: 200 damage per Spell in GY.
        if (GameManager.Instance.GetPlayerHandData().Count == 0)
        {
            int spells = GameManager.Instance.GetPlayerGraveyard().FindAll(c => c.type.Contains("Spell")).Count;
            Effect_DirectDamage(source, spells * 200);
        }
    }

    void Effect_1129_MagicalHats(CardDisplay source)
    {
        // Effect: Select 2 non-monster cards from Deck + 1 monster on field. Shuffle and Set face-down.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.type.Contains("Monster"),
                (monster) => {
                    List<CardData> deck = GameManager.Instance.GetPlayerMainDeck();
                    List<CardData> nonMonsters = deck.FindAll(c => !c.type.Contains("Monster"));
                    
                    if (nonMonsters.Count >= 2)
                    {
                        GameManager.Instance.OpenCardMultiSelection(nonMonsters, "Selecione 2 não-monstros", 2, 2, (selected) => {
                            // Change monster to face-down defense
                            if (monster.position == CardDisplay.BattlePosition.Attack) monster.ChangePosition();
                            monster.ShowBack();
                            
                            // Spawn tokens representing the hats (Simulated)
                            foreach(var c in selected)
                            {
                                GameManager.Instance.SpawnToken(source.isPlayerCard, 0, 0, "Magical Hat", 1, "Spellcaster", "Light");
                                deck.Remove(c);
                            }
                            GameManager.Instance.ShuffleDeck(source.isPlayerCard);
                            Debug.Log("Magical Hats: Monstro escondido e iscas posicionadas.");
                        });
                    }
                }
            );
        }
    }

    void Effect_1130_MagicalLabyrinth(CardDisplay source)
    {
        // Effect: Equip "Labyrinth Wall"; tribute it to SS "Wall Shadow".
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.CurrentCardData.name == "Labyrinth Wall",
                (t) => {
                    GameManager.Instance.TributeCard(t);
                    // SS Wall Shadow (ID 2048)
                    Effect_SearchDeck(source, "Wall Shadow", "Monster"); // Should be SS
                    Debug.Log("Magical Labyrinth: Wall Shadow invocado.");
                }
            );
        }
    }

    void Effect_1131_MagicalMarionette(CardDisplay source)
    {
        // Effect: Spell Counter on Spell activation. +200 ATK per counter. Remove 2 -> Destroy monster.
        if (SpellCounterManager.Instance.GetCount(source) >= 2)
        {
            if (SpellTrapManager.Instance != null)
            {
                SpellTrapManager.Instance.StartTargetSelection(
                    (t) => t.isOnField && t.CurrentCardData.type.Contains("Monster"),
                    (t) => {
                        SpellCounterManager.Instance.RemoveCounter(source, 2);
                        if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(t);
                        GameManager.Instance.SendToGraveyard(t.CurrentCardData, t.isPlayerCard);
                        Destroy(t.gameObject);
                    }
                );
            }
        }
    }

    void Effect_1132_MagicalMerchant(CardDisplay source)
    {
        // FLIP: Excavate until S/T found. Add to hand, send monsters to GY.
        List<CardData> deck = GameManager.Instance.GetPlayerMainDeck();
        List<CardData> excavated = new List<CardData>();
        CardData foundST = null;
        
        int index = 0;
        while (index < deck.Count)
        {
            CardData current = deck[index];
            excavated.Add(current);
            if (current.type.Contains("Spell") || current.type.Contains("Trap"))
            {
                foundST = current;
                break;
            }
            index++;
        }
        
        foreach (var c in excavated)
        {
            deck.Remove(c);
            if (c == foundST)
            {
                GameManager.Instance.AddCardToHand(c, source.isPlayerCard);
                Debug.Log($"Magical Merchant: Adicionou {c.name} à mão.");
            }
            else
            {
                GameManager.Instance.SendToGraveyard(c, source.isPlayerCard);
            }
        }
    }

    void Effect_1133_MagicalPlantMandragola(CardDisplay source)
    {
        // FLIP: Place 1 Spell Counter on each face-up card that can have one.
        if (GameManager.Instance.duelFieldUI != null)
        {
            // Simplificado: Adiciona a todos os monstros face-up
            List<CardDisplay> targets = new List<CardDisplay>();
            CollectMonsters(GameManager.Instance.duelFieldUI.playerMonsterZones, targets);
            CollectMonsters(GameManager.Instance.duelFieldUI.opponentMonsterZones, targets);
            
            foreach(var t in targets)
            {    
                if (!t.isFlipped) SpellCounterManager.Instance.AddCounter(t, 1);
            }
            Debug.Log("Mandragola: Contadores distribuídos.");
        }
    }

    void Effect_1134_MagicalScientist(CardDisplay source)
    {
        // Effect: Pay 1000 LP; SS 1 Level 6 or lower Fusion Monster from Extra Deck.
        // Cannot attack directly, return to Extra Deck at End Phase.
        if (Effect_PayLP(source, 1000))
        {
            List<CardData> extra = GameManager.Instance.GetPlayerExtraDeck();
            List<CardData> targets = extra.FindAll(c => c.type.Contains("Fusion") && c.level <= 6);
            
            if (targets.Count > 0)
            {
                GameManager.Instance.OpenCardSelection(targets, "Invocar Fusão Lv6-", (selected) => {
                    var summoned = GameManager.Instance.SpecialSummonFromData(selected, source.isPlayerCard);
                    if (summoned != null)
                    {
                        summoned.cannotAttackDirectly = true;
                        summoned.scheduledForReturnToExtraDeck = true;
                    }
                    extra.Remove(selected);
                });
            }
        }
    }

    void Effect_1135_MagicalStoneExcavation(CardDisplay source)
    {
        // Effect: Discard 2 cards; add 1 Spell Card from GY to hand.
        List<CardData> hand = GameManager.Instance.GetPlayerHandData();
        if (hand.Count >= 2)
        {
            GameManager.Instance.OpenCardMultiSelection(hand, "Descarte 2 cartas", 2, 2, (discarded) => {
                foreach(var c in discarded)
                {
                    GameManager.Instance.DiscardCard(GameManager.Instance.playerHand.Find(g => g.GetComponent<CardDisplay>().CurrentCardData == c).GetComponent<CardDisplay>());
                }
                
                
                List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
                List<CardData> spells = gy.FindAll(c => c.type.Contains("Spell"));
                if (spells.Count > 0)
                {
                    GameManager.Instance.OpenCardSelection(spells, "Recuperar Magia", (selected) => {
                        gy.Remove(selected);
                        GameManager.Instance.AddCardToHand(selected, source.isPlayerCard);
                    });
                }
            });
        }
    }

    void Effect_1136_MagicalThorn(CardDisplay source)
    {
        // Effect: When opponent discards from hand to GY, inflict 500 damage per card.
        // Lógica no OnCardDiscarded (CardEffectManager_Impl.cs).
        Debug.Log("Magical Thorn: Ativo (Gatilho de descarte configurado).");
    }

    void Effect_1137_MagicianOfBlackChaos(CardDisplay source)
    {
        Debug.Log("Magician of Black Chaos: Monstro Ritual (Sem efeito).");
    }

    void Effect_1138_MagicianOfFaith(CardDisplay source)
    {
        // FLIP: Target 1 Spell in GY; add to hand.
        List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
        List<CardData> spells = gy.FindAll(c => c.type.Contains("Spell"));
        
        if (spells.Count > 0)
        {
            GameManager.Instance.OpenCardSelection(spells, "Recuperar Magia", (selected) => {
                gy.Remove(selected);
                GameManager.Instance.AddCardToHand(selected, source.isPlayerCard);
            });
        }
    }

    void Effect_1139_MagiciansValkyria(CardDisplay source)
    {
        // Effect: Opponent cannot target other Spellcasters for attacks.
        Debug.Log("Magician's Valkyria: Proteção de Magos ativa (Passivo).");
    }

    void Effect_1140_MahaVailo(CardDisplay source)
    {
        // Effect: Gains 500 ATK for each Equip Card equipped to this card.
        CardLink[] links = Object.FindObjectsByType<CardLink>(FindObjectsSortMode.None);
        int equipCount = 0;
        foreach(var link in links)
        {
            if (link.target == source && link.type == CardLink.LinkType.Equipment)
                equipCount++;
        }
        
        source.RemoveModifiersFromSource(source);
        if (equipCount > 0)
        {
            source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, equipCount * 500, source));
        }
        Debug.Log($"Maha Vailo: {equipCount} equipamentos. +{equipCount*500} ATK.");
    }

    void Effect_1141_Maharaghi(CardDisplay source)
    {
        // Spirit. Summon/Flip: See top card of Deck.
        List<CardData> deck = GameManager.Instance.GetPlayerMainDeck();
        if (deck.Count > 0)
        {
            Debug.Log($"Maharaghi: Topo do deck é {deck[0].name}.");
        }
    }

    void Effect_1142_MaidenOfTheAqua(CardDisplay source)
    {
        // Effect: Field treated as Umi.
        // Lógica de verificação de Umi no GameManager deve incluir este card.
        Debug.Log("Maiden of the Aqua: Campo tratado como Umi (Passivo).");
    }

    void Effect_1144_MajiGirePanda(CardDisplay source)
    {
        // Effect: Gains 500 ATK when a Beast is destroyed.
        // Lógica no OnCardLeavesField.
        Debug.Log("Maji-Gire Panda: Efeito de ganho de ATK configurado.");
    }

    void Effect_1145_MajorRiot(CardDisplay source)
    {
        List<CardDisplay> pMonsters = new List<CardDisplay>();
        List<CardDisplay> oMonsters = new List<CardDisplay>();
        if (GameManager.Instance.duelFieldUI != null) {
            CollectMonsters(GameManager.Instance.duelFieldUI.playerMonsterZones, pMonsters);
            CollectMonsters(GameManager.Instance.duelFieldUI.opponentMonsterZones, oMonsters);
        }

        int pCount = pMonsters.Count;
        int oCount = oMonsters.Count;
        foreach(var m in pMonsters) GameManager.Instance.ReturnToHand(m);
        foreach(var m in oMonsters) GameManager.Instance.ReturnToHand(m);

        if (pCount > 0) {
            List<CardData> pHand = GameManager.Instance.GetPlayerHandData();
            List<CardData> pSummons = pHand.FindAll(c => c.type.Contains("Monster"));
            if (pSummons.Count > 0) {
                int max = Mathf.Min(pCount, pSummons.Count);
                GameManager.Instance.OpenCardMultiSelection(pSummons, $"Major Riot: SS até {max}", 1, max, (selected) => {
                    foreach(var c in selected) {
                        GameManager.Instance.SpecialSummonFromData(c, true, false, true); // Face-down defense
                        GameManager.Instance.RemoveCardFromHand(c, true);
                    }
                });
            }
        }
        if (oCount > 0) {
            List<CardData> oHand = GameManager.Instance.GetOpponentHandData();
            List<CardData> oSummons = oHand.FindAll(c => c.type.Contains("Monster"));
            int max = Mathf.Min(oCount, oSummons.Count);
            for(int i=0; i<max; i++) {
                GameManager.Instance.SpecialSummonFromData(oSummons[i], false, false, true);
                GameManager.Instance.RemoveCardFromHand(oSummons[i], false);
            }
        }
    }

    void Effect_1146_MajuGarzett(CardDisplay source)
    {
        // Effect: ATK = combined original ATK of 2 tributes.
        // Lógica no SummonManager.
        Debug.Log("Maju Garzett: ATK definido pelos tributos (Lógica no SummonManager).");
    }

    void Effect_1147_MakiuTheMagicalMist(CardDisplay source)
    {
        // Effect: Select 1 "Summoned Skull" or Thunder monster. Destroy all opp monsters with DEF < ATK of selected.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && (t.CurrentCardData.name == "Summoned Skull" || t.CurrentCardData.race == "Thunder"),
                (selected) => {
                    int threshold = selected.currentAtk;
                    List<CardDisplay> toDestroy = new List<CardDisplay>();
                    if (GameManager.Instance.duelFieldUI != null)
                    {
                        CollectMonsters(GameManager.Instance.duelFieldUI.opponentMonsterZones, toDestroy);
                    }
                    var targets = toDestroy.FindAll(m => !m.isFlipped && m.currentDef < threshold);
                    DestroyCards(targets, source.isPlayerCard);
                    selected.cannotAttackThisTurn = true;
                }
            );
        }
    }

    void Effect_1148_MakyuraTheDestructor(CardDisplay source)
    {
        // Effect: If sent to GY, can activate Traps from hand this turn.
        Debug.Log("Makyura: Traps da mão ativadas.");
        if (SpellTrapManager.Instance != null) SpellTrapManager.Instance.canActivateTrapsFromHand = true;
    }

    void Effect_1149_MalevolentCatastrophe(CardDisplay source)
    {
        // Effect: When opponent declares attack: Destroy all S/T.
        // Requer Trigger de ataque.
        Debug.Log("Malevolent Catastrophe: Destruindo todas as S/T.");
        Effect_HeavyStorm(source);
    }

    void Effect_1150_MalevolentNuzzler(CardDisplay source)
    {
        // Equip: +700 ATK. If sent to GY, pay 500 to return to top of Deck.
        Effect_Equip(source, 700, 0);
        // Lógica de retorno no OnCardSentToGraveyard.
    }

    void Effect_1151_MaliceDispersion(CardDisplay source)
    {
        // Effect: Discard 1 card; destroy all face-up Continuous Trap Cards.
        List<CardData> hand = GameManager.Instance.GetPlayerHandData();
        if (hand.Count > 0)
        {
            GameManager.Instance.OpenCardSelection(hand, "Descarte 1 carta", (discarded) => {
                GameManager.Instance.DiscardCard(GameManager.Instance.playerHand.Find(g => g.GetComponent<CardDisplay>().CurrentCardData == discarded).GetComponent<CardDisplay>());
                
                List<CardDisplay> toDestroy = new List<CardDisplay>();
                if (GameManager.Instance.duelFieldUI != null)
                {
                    List<Transform> zones = new List<Transform>();
                    zones.AddRange(GameManager.Instance.duelFieldUI.playerSpellZones);
                    zones.AddRange(GameManager.Instance.duelFieldUI.opponentSpellZones);
                    
                    foreach(var z in zones)
                    {
                        if (z.childCount > 0)
                        {
                            var cd = z.GetChild(0).GetComponent<CardDisplay>();
                            if (cd != null && !cd.isFlipped && cd.CurrentCardData.type.Contains("Trap") && cd.CurrentCardData.property == "Continuous")
                            {
                                toDestroy.Add(cd);
                            }
                        }
                    }
                }
                DestroyCards(toDestroy, source.isPlayerCard);
                Debug.Log("Malice Dispersion: Traps Contínuas destruídas.");
            });
        }
    }

    void Effect_1152_MaliceDollOfDemise(CardDisplay source)
    {
        // Effect: If sent from field to GY by effect of Continuous Spell, SS during Standby Phase.
        // Lógica no OnCardSentToGraveyard e OnPhaseStart.
        Debug.Log("Malice Doll of Demise: Gatilho de renascimento configurado.");
    }

    void Effect_1155_ManEaterBug(CardDisplay source)
    {
        // FLIP: Target 1 monster on the field; destroy it.
        Effect_FlipDestroy(source, TargetType.Monster);
    }

    void Effect_1159_ManThroTro(CardDisplay source)
    {
        // Effect: Tribute 1 Normal Monster; inflict 800 damage.
        // Simplificado: Usa helper genérico, mas idealmente filtraria por Normal Monster.
        Effect_TributeToBurn(source, 1, 800);
    }

    void Effect_1160_MangaRyuRan(CardDisplay source)
    {
        // Toon Monster.
        Debug.Log("Manga Ryu-Ran: Toon.");
    }

    void Effect_1161_ManjuOfTheTenThousandHands(CardDisplay source)
    {
        // Effect: When Normal/Flip Summoned: Add 1 Ritual Monster or Ritual Spell from Deck.
        Effect_SearchDeck(source, "Ritual");
    }

    void Effect_1162_ManticoreOfDarkness(CardDisplay source)
    {
        // Effect: End Phase: Send 1 Beast/Beast-Warrior from hand/field to GY to SS this card from GY.
        // Lógica no OnPhaseStart (End Phase).
        Debug.Log("Manticore of Darkness: Loop de renascimento configurado.");
    }

    void Effect_1163_MaraudingCaptain(CardDisplay source)
    {
        // Effect: Normal Summon -> SS 1 Lv4 or lower monster from hand. Opponent cannot target other Warriors for attacks.
        if (source.isOnField && source.summonedThisTurn)
        {
            List<CardData> hand = GameManager.Instance.GetPlayerHandData();
            List<CardData> targets = hand.FindAll(c => c.level <= 4 && c.type.Contains("Monster"));
            
            if (targets.Count > 0)
            {
                GameManager.Instance.OpenCardSelection(targets, "Invocar Lv4-", (selected) => {
                    GameManager.Instance.SpecialSummonFromData(selected, source.isPlayerCard);
                    GameManager.Instance.RemoveCardFromHand(selected, source.isPlayerCard);
                });
            }
        }
        // Proteção de ataque é passiva no BattleManager.
    }

    void Effect_1165_Marshmallon(CardDisplay source)
    {
        // Effect: Cannot be destroyed by battle. If attacked face-down: 1000 damage to attacker.
        // A indestrutibilidade é passiva (verificada no BattleManager se implementado, ou simulada aqui).
        // O dano é um efeito de gatilho após o cálculo de dano.
        Debug.Log("Marshmallon: Efeito passivo de indestrutibilidade e dano configurado.");

    }

    void Effect_1166_MarshmallonGlasses(CardDisplay source)
    {
        // Effect: Opponent can only select "Marshmallon" as an attack target.
        Debug.Log("Marshmallon Glasses: Oponente forçado a atacar Marshmallon (Passivo).");
    }

    void Effect_1167_Maryokutai(CardDisplay source)
    {
        // Effect: Quick Effect: Tribute this card to negate Spell activation and destroy it.
        var link = GetLinkToNegate(source);
        if (link != null && link.cardSource.CurrentCardData.type.Contains("Spell"))
        {
            GameManager.Instance.TributeCard(source);
            NegateAndDestroy(source, link);
        }
    }

    void Effect_1169_MaskOfBrutality(CardDisplay source)
    {
        // Equip: +1000 ATK, -1000 DEF. Pay 1000 LP each Standby Phase.
        Effect_Equip(source, 1000, -1000);
        // Manutenção no CheckMaintenanceCosts.
    }

    void Effect_1170_MaskOfDarkness(CardDisplay source)
    {
        // FLIP: Target 1 Trap in GY; add to hand.
        List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
        List<CardData> traps = gy.FindAll(c => c.type.Contains("Trap"));
        
        if (traps.Count > 0)
        {
            GameManager.Instance.OpenCardSelection(traps, "Recuperar Trap", (selected) => {
                gy.Remove(selected);
                GameManager.Instance.AddCardToHand(selected, source.isPlayerCard);
            });
        }
    }

    void Effect_1171_MaskOfDispel(CardDisplay source)
    {
        // Select 1 face-up Spell. Controller takes 500 damage each Standby Phase.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.CurrentCardData.type.Contains("Spell") && !t.isFlipped,
                (target) => {
                    Debug.Log($"Mask of Dispel: Alvejando {target.CurrentCardData.name}.");
                    // Cria um link para rastrear o alvo durante a Standby Phase
                    GameManager.Instance.CreateCardLink(source, target, CardLink.LinkType.Continuous);
                }
            );
        }
    }

    void Effect_1172_MaskOfRestrict(CardDisplay source)
    {
        Debug.Log("Mask of Restrict: Tributos bloqueados (Tratado no SummonManager).");
    }

    void Effect_1173_MaskOfWeakness(CardDisplay source)
    {
        // Target attacking monster; -700 ATK until end of turn.
        if (BattleManager.Instance != null && BattleManager.Instance.currentAttacker != null)
        {
            BattleManager.Instance.currentAttacker.ModifyStats(-700, 0);
            Debug.Log("Mask of Weakness: -700 ATK no atacante.");
        }
    }

    void Effect_1174_MaskOfTheAccursed(CardDisplay source)
    {
        // Equip: Cannot attack. 500 damage to controller each Standby Phase.
        Effect_Equip(source, 0, 0);
        // Lógica de bloqueio e dano.
    }

    void Effect_1175_MaskedBeastDesGardius(CardDisplay source)
    {
        // If sent to GY: Equip "The Mask of Remnants" from Deck/Hand to opp monster and take control.
        // Lógica implementada no OnCardSentToGraveyard (CardEffectManager_Impl.cs)
        Debug.Log("Des Gardius: Efeito de controle ao morrer configurado.");
    }

    void Effect_1177_MaskedDragon(CardDisplay source)
    {
        // Effect: Destroyed by battle -> SS Dragon with ATK <= 1500 from Deck.
        Effect_SearchDeck(source, "Dragon", "Monster", 1500); // Simplificado para busca
    }

    void Effect_1178_MaskedSorcerer(CardDisplay source)
    {
        // Effect: If inflicts battle damage: Draw 1 card.
        // Lógica implementada no OnDamageDealtImpl (CardEffectManager_Impl.cs)
        Debug.Log("Masked Sorcerer: Efeito de compra configurado.");
    }

    void Effect_1179_MassDriver(CardDisplay source)
    {
        // Effect: Tribute 1 monster; inflict 400 damage.
        Effect_TributeToBurn(source, 1, 400);
    }

    void Effect_1182_MasterMonk(CardDisplay source)
    {
        Debug.Log("Master Monk: Ataque duplo configurado em OnSummonImpl.");
    }

    void Effect_1184_MatazaTheZapper(CardDisplay source)
    {
        Debug.Log("Mataza: Ataque duplo configurado em OnSummonImpl.");
    }

    void Effect_1186_MaximumSix(CardDisplay source)
    {
        // Effect: When Tribute Summoned: Roll die. Gain ATK = result * 200.
        if (source.isOnField)
        {
            GameManager.Instance.TossCoin(1, (heads) => { // Simula dado
                int roll = Random.Range(1, 7);
                int buff = roll * 200;
                source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, buff, source));
                Debug.Log($"Maximum Six: Rolou {roll}. +{buff} ATK.");
            });
        }
    }

    void Effect_1187_MazeraDeVille(CardDisplay source)
    {
        // Effect: Cannot be Normal Summoned. SS by tributing Warrior of Zera while Pandemonium is on field. Opponent discards 3 random cards.
        if (source.isOnField)
        {
            GameManager.Instance.DiscardRandomHand(false, 3);
            Debug.Log("Mazera DeVille: Oponente descartou 3 cartas.");
        }
    }

    void Effect_1190_MechaDogMarron(CardDisplay source)
    {
        // Effect: If destroyed by battle: Both players take 1000 damage.
        // Lógica implementada no OnBattleEnd (CardEffectManager_Impl.cs)
        Debug.Log("Mecha-Dog Marron: Dano mútuo ao morrer.");
    }

    void Effect_1192_MechanicalHound(CardDisplay source)
    {
        // Effect: If you have no cards in hand, opponent cannot activate Spells.
        Debug.Log("Mechanical Hound: Bloqueio de Magias (Passivo).");
    }

    void Effect_1196_MedusaWorm(CardDisplay source)
    {
        // Effect: Flip: Destroy 1 monster opp controls. Can flip face-down once per turn.
        if (source.isFlipped)
        {
            Effect_FlipDestroy(source, TargetType.Monster);
        }
        else
        {
            Effect_TurnSet(source);
        }
    }

    void Effect_1197_MefistTheInfernalGeneral(CardDisplay source)
    {
        // Effect: Piercing damage. If inflicts battle damage: Opponent discards 1 random card.
        // Lógica de piercing no BattleManager. Lógica de descarte no OnDamageDealtImpl (CardEffectManager_Impl.cs).
        Debug.Log("Mefist: Efeitos de batalha configurados.");
    }

    void Effect_1199_MegaTonMagicalCannon(CardDisplay source)
    {
        // Effect: Remove 10 Spell Counters from your field; destroy all cards opponent controls.
        if (RemoveSpellCounters(10, source.isPlayerCard))
        if (SpellCounterManager.Instance.RemoveCountersFromField(10, source.isPlayerCard))
        {
            DestroyAllMonsters(true, false);
            DestroyAllMonsters(true, false); // Destrói monstros
            Effect_HarpiesFeatherDuster(source);
            Debug.Log("Mega Ton Magical Cannon: Campo do oponente limpo.");
        }
    }

    void Effect_1200_Megamorph(CardDisplay source)
    {
        // Effect: Equip. While your Life Points are lower than your opponent's, double the original ATK of the equipped monster. While your Life Points are higher, halve the original ATK of the equipped monster.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (target) => target.isOnField && target.CurrentCardData.type.Contains("Monster"),
                (target) => 
                {
                    Debug.Log($"{source.CurrentCardData.name} equipada em {target.CurrentCardData.name}");
                    GameManager.Instance.CreateCardLink(source, target, CardLink.LinkType.Equipment);
                    UpdateMegamorphStats(source, target);
                }
            );
        }
    }

    void Effect_1201_MegarockDragon(CardDisplay source)
    {
        // Effect: Cannot be Normal Summoned. SS by banishing Rock monsters from GY. ATK/DEF = 700 * banished.
        if (!source.isOnField)
        {
            List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
            List<CardData> rocks = gy.FindAll(c => c.race == "Rock");
            
            if (rocks.Count > 0)
            {
                GameManager.Instance.OpenCardMultiSelection(rocks, "Banir Rocks", 1, rocks.Count, (selected) => {
                    foreach(var c in selected)
                    {
                        GameManager.Instance.RemoveFromPlay(c, source.isPlayerCard);
                        gy.Remove(c);
                    }
                    var summoned = GameManager.Instance.SpecialSummonFromData(source.CurrentCardData, source.isPlayerCard);
                    GameManager.Instance.RemoveCardFromHand(source.CurrentCardData, source.isPlayerCard);
                    
                    if (summoned != null) {
                        summoned.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, selected.Count * 700, summoned));
                        summoned.AddStatModifier(new StatModifier(StatModifier.StatType.DEF, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, selected.Count * 700, summoned));
                    }
                });
            }
        }
    }

    void Effect_1207_MermaidKnight(CardDisplay source)
    {
        // Effect: If "Umi" is active, can attack twice.
        // A permissão de ataque duplo é verificada no BattleManager.
        if (GameManager.Instance.IsCardActiveOnField("2015") || GameManager.Instance.IsCardActiveOnField("0013"))
        {
            Debug.Log("Mermaid Knight: Ataque duplo ativo.");
            // source.canAttackTwice = true;
        }
    }

    void Effect_1208_MesmericControl(CardDisplay source)
    {
        // Effect: Opponent cannot change battle positions of monsters next turn.
        if (BattleManager.Instance != null)
        {
            BattleManager.Instance.battlePositionsLocked = true; // Flag resetada no End Phase do oponente
            Debug.Log("Mesmeric Control: Posições de batalha travadas para o próximo turno.");
        }
    }

    void Effect_1209_MessengerOfPeace(CardDisplay source)
    {
        // Effect: Monsters with 1500+ ATK cannot attack. Pay 100 LP standby.
        // Bloqueio implementado no BattleManager.CanAttack.
        // Manutenção implementada no CheckMaintenanceCosts.
        Debug.Log("Messenger of Peace: Ativo.");
    }

    void Effect_1211_MetalDetector(CardDisplay source)
    {
        var link = GetLinkToNegate(source);
        if (link != null && link.cardSource.CurrentCardData.type.Contains("Trap") && link.cardSource.CurrentCardData.property == "Continuous")
        {
            NegateAndDestroy(source, link);
        }
    }

    void Effect_1215_MetalReflectSlime(CardDisplay source)
    {
        if (GameManager.Instance.ConvertTrapToMonster(source, 0, 3000, 10, "Aqua", "Water"))
        {
            Debug.Log("Metal Reflect Slime: Invocado perfeitamente como Trap Monster.");
        }
    }

    void Effect_1216_MetallizingParasiteLunatite(CardDisplay source)
    {
        // Effect: Union. Equipped monster unaffected by opp Spells.
        Effect_Union(source, "Monster", 0, 0); // Alvo genérico
    }

    void Effect_1217_Metalmorph(CardDisplay source)
    {
        // Effect: Equip. +300 ATK/DEF. If attacks, gain half ATK of target.
        Effect_Equip(source, 300, 300);
        // Lógica de ganho de ATK no ataque deve ser no OnDamageCalculation.
    }

    void Effect_1218_MetalsilverArmor(CardDisplay source)
    {
        // Effect: Opponent can only target equipped monster.
        Effect_Equip(source, 0, 0);
        Debug.Log("Metalsilver Armor: Redirecionamento de alvo.");
    }

    void Effect_1219_Metalzoa(CardDisplay source)
    {
        // Effect: SS from Deck by tributing Zoa equipped with Metalmorph.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.CurrentCardData.name == "Zoa", // Deveria checar Metalmorph
                (t) => {
                    GameManager.Instance.TributeCard(t);
                    // SS Metalzoa do Deck
                    Effect_SpecialSummonFromDeck(source, nameContains: "Metalzoa");
                }
            );
        }
    }

    void Effect_1220_Metamorphosis(CardDisplay source)
    {
        // Effect: Tribute 1 monster; SS Fusion Monster with same Level from Extra Deck.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard,
                (tribute) => {
                    int level = tribute.CurrentCardData.level;
                    GameManager.Instance.TributeCard(tribute);
                    
                    List<CardData> extra = GameManager.Instance.GetPlayerExtraDeck();
                    List<CardData> targets = extra.FindAll(c => c.level == level);
                    
                    if (targets.Count > 0)
                    {
                        GameManager.Instance.OpenCardSelection(targets, "Invocar Fusão", (selected) => {
                            GameManager.Instance.SpecialSummonFromData(selected, source.isPlayerCard);
                            extra.Remove(selected);
                        });
                    }
                }
            );
        }
    }

    void Effect_1223_MeteorOfDestruction(CardDisplay source)
    {
        // Effect: If opp LP > 3000, inflict 1000 damage.
        if (GameManager.Instance.opponentLP > 3000)
        {
            Effect_DirectDamage(source, 1000);
        }
    }

    void Effect_1224_Meteorain(CardDisplay source)
    {
        // Effect: All your monsters inflict piercing damage this turn.
        if (BattleManager.Instance != null)
        {
            BattleManager.Instance.globalPiercing = true; // Resetar no End Phase
            Debug.Log("Meteorain: Dano perfurante global ativado.");
        }
    }

    void Effect_1225_Michizure(CardDisplay source)
    {
        // Effect: When monster sent to GY: Destroy 1 monster.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.CurrentCardData.type.Contains("Monster"),
                (t) => {
                    if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(t);
                    GameManager.Instance.SendToGraveyard(t.CurrentCardData, t.isPlayerCard);
                    Destroy(t.gameObject);
                }
            );
        }
    }
    // 1226 - Micro Ray
    void Effect_1226_MicroRay(CardDisplay source)
    {
        // Target 1 face-up monster on the field; that target's DEF becomes 0 until the end of this turn.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.CurrentCardData.type.Contains("Monster") && !t.isFlipped,
                (target) => {
                    // Define DEF para 0 (usando modificador SET)
                    target.AddStatModifier(new StatModifier(StatModifier.StatType.DEF, StatModifier.ModifierType.Temporary, StatModifier.Operation.Set, 0, source));
                    Debug.Log($"Micro Ray: DEF de {target.CurrentCardData.name} tornou-se 0.");
                }
            );
        }
    }

    // 1227 - Mid Shield Gardna
    void Effect_1227_MidShieldGardna(CardDisplay source)
    {
        // Ignition: Flip face-down.
        // Trigger (Passive): Negate Spell targeting this face-down.
        // A parte de negação é passiva/trigger no SpellTrapManager.
        // A parte de ignição (virar face-down):
        if (source.isOnField && !source.isFlipped)
        {
            Effect_TurnSet(source);
        }
    }

    // 1232 - Millennium Scorpion
    void Effect_1232_MillenniumScorpion(CardDisplay source)
    {
        // Gains 500 ATK each time it destroys a monster by battle.
        // Lógica implementada no OnBattleEnd.
    }

    // 1234 - Milus Radiant
    void Effect_1234_MilusRadiant(CardDisplay source)
    {
        // EARTH +500 ATK, WIND -400 ATK.
        Effect_Field(source, 500, 0, "", "Earth");
        Effect_Field(source, -400, 0, "", "Wind");
    }

    // 1235 - Minar
    void Effect_1235_Minar(CardDisplay source)
    {
        // If discarded by opponent's effect: 1000 damage.
        // Lógica implementada no OnCardDiscarded.
    }

    // 1236 - Mind Control
    void Effect_1236_MindControl(CardDisplay source)
    {
        // Pay 800 LP (Errata: No LP cost in modern, but keeping classic if needed. Let's assume classic/modern mix or no cost as per text provided in prompt list? Prompt didn't specify cost, usually 800 is Brain Control. Mind Control is usually no cost but cannot attack/tribute).
        // Text: Target 1 monster opp controls; take control until End Phase. Cannot attack/Tribute.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && !t.isPlayerCard && t.CurrentCardData.type.Contains("Monster"),
                (target) => {
                    GameManager.Instance.SwitchControl(target);
                    // Aplica restrições
                    target.hasAttackedThisTurn = true; // Impede ataque (hack simples)
                    // TODO: Adicionar flag 'cannotBeTributed' no CardDisplay
                    Debug.Log($"Mind Control: Controlando {target.CurrentCardData.name} até a End Phase.");
                    // Agendar retorno na End Phase (GameManager deve tratar isso na limpeza de turno ou via CardLink)
                }
            );
        }
    }

    // 1237 - Mind Crush
    void Effect_1237_MindCrush(CardDisplay source)
    {
        if (GlobalCardSearchUI.Instance != null)
        {
            GlobalCardSearchUI.Instance.Show("Declare o nome de 1 carta", (declaredCard) => {
                if (declaredCard == null) return;
                
                List<CardData> oppHand = GameManager.Instance.GetOpponentHandData();
                List<CardData> hits = oppHand.FindAll(c => c.name == declaredCard.name);
                
                if (hits.Count > 0)
                {
                    Debug.Log($"Mind Crush: Acertou! Oponente descarta {hits.Count} cópias de {declaredCard.name}.");
                    GameManager.Instance.DiscardCardsByName(false, declaredCard.name);
                }
                else
                {
                    Debug.Log("Mind Crush: Errou! Você descarta 1 carta aleatória.");
                    GameManager.Instance.DiscardRandomHand(source.isPlayerCard, 1);
                }
            });
        }
    }

    // 1238 - Mind Haxorz
    void Effect_1238_MindHaxorz(CardDisplay source)
    {
        // Pay 500. Look at opp hand and Set cards.
        if (Effect_PayLP(source, 500))
        {
            Debug.Log("Mind Haxorz: Revelando mão e campo do oponente...");
            GameManager.Instance.ToggleOpponentHandVisibility(); // Revela mão (Dev tool usada como feature)
            // Revelar setadas
            if (GameManager.Instance.duelFieldUI != null)
            {
                foreach(var z in GameManager.Instance.duelFieldUI.opponentSpellZones)
                {
                    if(z.childCount > 0) z.GetChild(0).GetComponent<CardDisplay>().RevealCard();
                }
                foreach(var z in GameManager.Instance.duelFieldUI.opponentMonsterZones)
                {
                    if(z.childCount > 0) 
                    {
                        var m = z.GetChild(0).GetComponent<CardDisplay>();
                        if(m.isFlipped) m.RevealCard();
                    }
                }
            }
        }
    }

    // 1239 - Mind Wipe
    void Effect_1239_MindWipe(CardDisplay source)
    {
        // Activate if opp hand <= 3. Opponent shuffles hand to deck, draws same number.
        List<CardData> oppHand = GameManager.Instance.GetOpponentHandData();
        if (oppHand.Count <= 3 && oppHand.Count > 0)
        {
            int count = oppHand.Count;
            GameManager.Instance.DiscardHand(false); // Deveria ser Shuffle into Deck
            for(int i=0; i<count; i++) GameManager.Instance.DrawOpponentCard();
            Debug.Log("Mind Wipe: Mão do oponente reciclada.");
        }
    }

    // 1240 - Mind on Air
    void Effect_1240_MindOnAir(CardDisplay source)
    {
        // Opponent plays with hand revealed.
        Debug.Log("Mind on Air: Mão do oponente revelada.");
        GameManager.Instance.showOpponentHand = true;
        // Nota: Precisa desligar quando sair do campo (OnCardLeavesField)
    }

    // 1241 - Mine Golem
    void Effect_1241_MineGolem(CardDisplay source)
    {
        // If destroyed by battle: 500 damage to opp.
        // Lógica implementada no OnCardSentToGraveyard.
    }

    // 1242 - Minefield Eruption
    void Effect_1242_MinefieldEruption(CardDisplay source)
    {
        // Damage 1000 per Mine Golem, then destroy them.
        int count = 0;
        List<CardDisplay> golems = new List<CardDisplay>();
        
        if (GameManager.Instance.duelFieldUI != null)
        {
            foreach(var z in GameManager.Instance.duelFieldUI.playerMonsterZones)
            {
                if(z.childCount > 0)
                {
                    var m = z.GetChild(0).GetComponent<CardDisplay>();
                    if(m != null && m.CurrentCardData.name == "Mine Golem")
                    {
                        count++;
                        golems.Add(m);
                    }
                }
            }
        }

        if (count > 0)
        {
            Effect_DirectDamage(source, golems.Count * 1000);
            foreach(var g in golems)
            {
                GameManager.Instance.SendToGraveyard(g.CurrentCardData, true);
                Destroy(g.gameObject);
            }
            Debug.Log($"Minefield Eruption: {count} Golems explodiram.");
        }
    }

    // 1244 - Minor Goblin Official
    void Effect_1244_MinorGoblinOfficial(CardDisplay source)
    {
        // Opponent LP <= 3000 -> 500 dmg each Standby.
        // Lógica implementada no OnPhaseStart.
    }

    // 1251 - Mirror Force
    void Effect_1251_MirrorForce(CardDisplay source)
    {
        Effect_MirrorForce(source);
    }

    // 1245 - Miracle Dig
    void Effect_1245_MiracleDig(CardDisplay source)
    {
        // If 5+ banished, return 3 to GY.
        List<CardData> banished = GameManager.Instance.GetPlayerRemoved();
        if (banished.Count >= 5)
        {
            GameManager.Instance.OpenCardMultiSelection(banished, "Retornar 3 ao GY", 3, 3, (selected) => {
                foreach(var c in selected)
                {
                    banished.Remove(c); // Remove da lista de banidos
                    GameManager.Instance.GetPlayerGraveyard().Add(c); // Adiciona ao GY
                }
                // Atualiza visuais
                GameManager.Instance.playerRemovedDisplay.UpdatePile(banished, GameManager.Instance.GetCardBackTexture());
                GameManager.Instance.playerGraveyardDisplay.UpdatePile(GameManager.Instance.GetPlayerGraveyard(), GameManager.Instance.GetCardBackTexture());
                Debug.Log("Miracle Dig: 3 cartas retornadas ao GY.");
            });
        }
    }

    // 1246 - Miracle Fusion
    void Effect_1246_MiracleFusion(CardDisplay source)
    {
        // Fusion Summon E-Hero by banishing materials from Field/GY.
        List<CardData> extra = GameManager.Instance.GetPlayerExtraDeck();
        List<CardData> heroes = extra.FindAll(c => c.name.Contains("Elemental HERO"));
        
        if (heroes.Count > 0)
        {
            GameManager.Instance.OpenCardSelection(heroes, "Miracle Fusion", (fusionTarget) => {
                List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
                if (gy.Count > 0) {
                    int max = Mathf.Min(5, gy.Count);
                    GameManager.Instance.OpenCardMultiSelection(gy, "Banir materiais", 1, max, (materials) => {
                        foreach(var m in materials) {
                            GameManager.Instance.RemoveFromPlay(m, source.isPlayerCard);
                            gy.Remove(m);
                        }
                        GameManager.Instance.SpecialSummonFromData(fusionTarget, source.isPlayerCard);
                        extra.Remove(fusionTarget);
                    });
                }
            });
        }
    }

    // 1247 - Miracle Restoring
    void Effect_1247_MiracleRestoring(CardDisplay source)
    {
        // Remove 2 counters -> SS Dark Magician or Buster Blader from GY.
        if (RemoveSpellCounters(2, source.isPlayerCard))
        if (SpellCounterManager.Instance.RemoveCountersFromField(2, source.isPlayerCard))
        {
            List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
            List<CardData> targets = gy.FindAll(c => c.name == "Dark Magician" || c.name == "Buster Blader");
            
            if (targets.Count > 0)
            {
                GameManager.Instance.OpenCardSelection(targets, "Reviver Lenda", (selected) => {
                    GameManager.Instance.SpecialSummonFromData(selected, source.isPlayerCard);
                });
            }
        }
    }

    // 1248 - Mirage Dragon
    void Effect_1248_MirageDragon(CardDisplay source)
    {
        // Opponent cannot activate Traps during Battle Phase.
        // Lógica implementada no BattleManager.
    }

    // 1249 - Mirage Knight
    void Effect_1249_MirageKnight(CardDisplay source)
    {
        // Gain ATK = Opponent's ATK during calc. Banish at End Phase.
        // Lógica implementada no OnDamageCalculation e OnPhaseStart.
    }

    // 1250 - Mirage of Nightmare
    void Effect_1250_MirageOfNightmare(CardDisplay source)
    {
        // Opponent's Standby: Draw until 4. Your Standby: Discard same amount.
        // Lógica implementada no OnPhaseStart.
    }

        // 1251 - Mirror Force (Já implementado como Effect_MirrorForce, mantendo referência)
    
    // 1252 - Mirror Wall
    void Effect_1252_MirrorWall(CardDisplay source)
    {
        // Effect: Halve ATK of opponent's attacking monsters. Pay 2000 LP during Standby.
        // Lógica implementada no OnDamageCalculation e CheckMaintenanceCosts.
    }

    // 1254 - Mispolymerization
    void Effect_1254_Mispolymerization(CardDisplay source)
    {
        // Effect: Return all Fusion Monsters to the Extra Deck.
        List<CardDisplay> fusions = new List<CardDisplay>();
        if (GameManager.Instance.duelFieldUI != null)
        {
            List<CardDisplay> all = new List<CardDisplay>();
            CollectMonsters(GameManager.Instance.duelFieldUI.playerMonsterZones, all);
            CollectMonsters(GameManager.Instance.duelFieldUI.opponentMonsterZones, all);
            
            foreach(var m in all)
            {
                if (m.CurrentCardData.type.Contains("Fusion")) fusions.Add(m);
            }
        }

        foreach(var f in fusions.FindAll(m => m.CurrentCardData.type.Contains("Fusion")))
        {
            CardData data = f.CurrentCardData;
            bool isPlayer = f.isPlayerCard;
            if (CardEffectManager.Instance != null) CardEffectManager.Instance.OnCardLeavesField(f);
            Destroy(f.gameObject);
            
            List<CardData> extra = isPlayer ? GameManager.Instance.GetPlayerExtraDeck() : GameManager.Instance.GetOpponentExtraDeck();
            extra.Add(data);
        }
    }

    // 1255 - Moai Interceptor Cannons
    void Effect_1255_MoaiInterceptorCannons(CardDisplay source)
    {
        // Effect: Once per turn, flip face-down.
        if (source.isOnField && !source.isFlipped)
        {
            Effect_TurnSet(source);
        }
    }

    // 1256 - Mobius the Frost Monarch
    void Effect_1256_MobiusTheFrostMonarch(CardDisplay source)
    {
        // Effect: When Tribute Summoned: Target up to 2 S/T; destroy them.
        if (source.summonedThisTurn && source.isTributeSummoned)
        {
            if (SpellTrapManager.Instance != null)
            {
                List<CardDisplay> st = new List<CardDisplay>();
                if (GameManager.Instance.duelFieldUI != null) {
                    CollectCards(GameManager.Instance.duelFieldUI.playerSpellZones, st);
                    CollectCards(GameManager.Instance.duelFieldUI.opponentSpellZones, st);
                }
                if (st.Count > 0) {
                    SpellTrapManager.Instance.StartTargetSelection(
                        (t) => t.isOnField && (t.CurrentCardData.type.Contains("Spell") || t.CurrentCardData.type.Contains("Trap")),
                        (t1) => {
                            if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(t1);
                            GameManager.Instance.SendToGraveyard(t1.CurrentCardData, t1.isPlayerCard);
                            Destroy(t1.gameObject);
                            st.Remove(t1);
                            if (st.Count > 0 && UIManager.Instance != null) {
                                UIManager.Instance.ShowConfirmation("Destruir mais uma S/T?", () => {
                                    SpellTrapManager.Instance.StartTargetSelection((t2) => t2.isOnField && (t2.CurrentCardData.type.Contains("Spell") || t2.CurrentCardData.type.Contains("Trap")), (t3) => {
                                        if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(t3);
                                        GameManager.Instance.SendToGraveyard(t3.CurrentCardData, t3.isPlayerCard);
                                        Destroy(t3.gameObject);
                                    });
                                }, null);
                            }
                        });
                }
            }
        }
    }

    // 1257 - Moisture Creature
    void Effect_1257_MoistureCreature(CardDisplay source)
    {
        // Effect: If Tribute Summoned by 3 Tributes: Destroy all S/T opp controls.
        // Requer saber quantos tributos foram usados.
        // Como o sistema atual não passa a contagem exata (apenas flag bool), assumimos que se foi Tribute Summoned, o jogador cumpriu o requisito se escolheu essa opção.
        // Em um sistema completo, precisaríamos de `source.tributeCount`.
        if (source.summonedThisTurn && source.isTributeSummoned && source.tributeCount >= 3)
        {
            Debug.Log("Moisture Creature: Destruindo S/T do oponente.");
            Effect_HarpiesFeatherDuster(source);
        }
    }

    // 1259 - Mokey Mokey Smackdown
    void Effect_1259_MokeyMokeySmackdown(CardDisplay source)
    {
        Debug.Log("Mokey Mokey Smackdown: Resolvido no trigger OnCardSentToGraveyard.");
    }

    // 1261 - Molten Destruction
    void Effect_1261_MoltenDestruction(CardDisplay source)
    {
        Effect_Field(source, 500, -400, "", "Fire");
    }

    // 1262 - Molten Zombie
    void Effect_1262_MoltenZombie(CardDisplay source)
    {
        // Effect: When SS from GY: Draw 1 card.
        // Lógica implementada no OnSpecialSummon.
    }

    // 1264 - Monk Fighter
    void Effect_1264_MonkFighter(CardDisplay source)
    {
        // Effect: Battle Damage to controller is 0.
        // Lógica no OnDamageCalculation.
        Debug.Log("Monk Fighter: Dano de batalha 0.");
    }

    // 1266 - Monster Eye
    void Effect_1266_MonsterEye(CardDisplay source)
    {
        // Effect: Pay 1000 LP; add 1 Polymerization from GY to hand.
        if (Effect_PayLP(source, 1000))
        {
            List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
            CardData poly = gy.Find(c => c.name == "Polymerization");
            if (poly != null)
            {
                gy.Remove(poly);
                GameManager.Instance.AddCardToHand(poly, source.isPlayerCard);
                Debug.Log("Monster Eye: Polymerization recuperada.");
            }
        }
    }

    // 1267 - Monster Gate
    void Effect_1267_MonsterGate(CardDisplay source)
    {
        // Effect: Tribute 1 monster; excavate until Normal Summonable monster, SS it, send rest to GY.
        if (source.isOnField) // Deveria ser ativado da mão/campo como Spell
        {
            if (SpellTrapManager.Instance != null)
            {
                SpellTrapManager.Instance.StartTargetSelection(
                    (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.type.Contains("Monster"),
                    (tribute) => {
                        GameManager.Instance.TributeCard(tribute);
                        
                        List<CardData> deck = GameManager.Instance.GetPlayerMainDeck();
                        List<CardData> sentToGY = new List<CardData>();
                        CardData foundMonster = null;

                        while (deck.Count > 0)
                        {
                            CardData current = deck[0];
                            deck.RemoveAt(0);
                            
                            if (current.type.Contains("Monster") && !current.type.Contains("Ritual") && !current.type.Contains("Fusion"))
                            {
                                foundMonster = current;
                                break;
                            }
                            else
                            {
                                sentToGY.Add(current);
                            }
                        }

                        foreach(var c in sentToGY) GameManager.Instance.SendToGraveyard(c, source.isPlayerCard);

                        if (foundMonster != null)
                        {
                            GameManager.Instance.SpecialSummonFromData(foundMonster, source.isPlayerCard);
                        }
                    }
                );
            }
        }
    }

    // 1268 - Monster Reborn
    void Effect_1268_MonsterReborn(CardDisplay source)
    {
        Effect_Revive(source, true); // true = any graveyard
    }

    // 1269 - Monster Recovery
    void Effect_1269_MonsterRecovery(CardDisplay source)
    {
        // Effect: Target 1 monster you own; shuffle it and hand into Deck, draw hand size.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.type.Contains("Monster"),
                (target) => {
                    int handCount = GameManager.Instance.GetPlayerHandData().Count;
                    
                    GameManager.Instance.ReturnToDeck(target, false);
                    GameManager.Instance.ReturnHandToDeck(source.isPlayerCard);
                    
                    for(int i=0; i<handCount; i++) GameManager.Instance.DrawCard();
                }
            );
        }
    }

    // 1274 - Mooyan Curry
    void Effect_1274_MooyanCurry(CardDisplay source)
    {
        Effect_GainLP(source, 200);
    }

    // 1275 - Morale Boost
    void Effect_1275_MoraleBoost(CardDisplay source)
    {
        // Effect: Equip Spell activated -> Gain 1000. Equip Spell removed -> Take 1000.
        // Lógica implementada via hooks globais no CardEffectManager_Impl.cs.
        Debug.Log("Morale Boost: Ativo.");
    }

    // 1277 - Morphing Jar
    void Effect_1277_MorphingJar(CardDisplay source)
    {
        // FLIP: Both players discard their entire hands, then draw 5 cards.
        GameManager.Instance.DiscardHand(true);
        GameManager.Instance.DiscardHand(false);
        
        for(int i=0; i<5; i++) GameManager.Instance.DrawCard(true); // ignoreLimit
        for(int i=0; i<5; i++) GameManager.Instance.DrawOpponentCard();
        
        Debug.Log("Morphing Jar: Mãos resetadas para 5 cartas.");
    }

    // 1278 - Morphing Jar #2
    void Effect_1278_MorphingJar2(CardDisplay source)
    {
        List<CardDisplay> pMonsters = new List<CardDisplay>();
        List<CardDisplay> oMonsters = new List<CardDisplay>();
        if (GameManager.Instance.duelFieldUI != null)
        {
            CollectMonsters(GameManager.Instance.duelFieldUI.playerMonsterZones, pMonsters);
            CollectMonsters(GameManager.Instance.duelFieldUI.opponentMonsterZones, oMonsters);
        }
        
        int pCount = pMonsters.Count;
        int oCount = oMonsters.Count;
        
        foreach(var m in pMonsters) GameManager.Instance.ReturnToDeck(m, false);
        foreach(var m in oMonsters) GameManager.Instance.ReturnToDeck(m, false);
        
        GameManager.Instance.ShuffleDeck(true);
        GameManager.Instance.ShuffleDeck(false);

        List<CardData> pDeck = GameManager.Instance.GetPlayerMainDeck();
        List<CardData> pSentToGY = new List<CardData>();
        int pFound = 0;
        while(pDeck.Count > 0 && pFound < pCount)
        {
            CardData c = pDeck[0];
            pDeck.RemoveAt(0);
            if (c.type.Contains("Monster") && c.level <= 4 && !c.type.Contains("Ritual") && !c.type.Contains("Fusion"))
            {
                GameManager.Instance.SpecialSummonFromData(c, true, false, true); // Face-down Defense
                pFound++;
            }
            else pSentToGY.Add(c);
        }
        foreach(var c in pSentToGY) GameManager.Instance.SendToGraveyard(c, true);

        List<CardData> oDeck = GameManager.Instance.GetOpponentMainDeck();
        List<CardData> oSentToGY = new List<CardData>();
        int oFound = 0;
        while(oDeck.Count > 0 && oFound < oCount)
        {
            CardData c = oDeck[0];
            oDeck.RemoveAt(0);
            if (c.type.Contains("Monster") && c.level <= 4 && !c.type.Contains("Ritual") && !c.type.Contains("Fusion"))
            {
                GameManager.Instance.SpecialSummonFromData(c, false, false, true); // Face-down Defense
                oFound++;
            }
            else oSentToGY.Add(c);
        }
        foreach(var c in oSentToGY) GameManager.Instance.SendToGraveyard(c, false);
    }

    // 1279 - Mother Grizzly
    void Effect_1279_MotherGrizzly(CardDisplay source)
    {
        // When destroyed by battle: SS 1 WATER monster with 1500 or less ATK from Deck.
        Effect_SearchDeck(source, "Water", "Monster", 1500); // Simplificado para busca, idealmente SS
    }

    // 1280 - Mountain
    void Effect_1280_Mountain(CardDisplay source)
    {
        // Field: Dragon, Winged Beast, Thunder +200 ATK/DEF.
        Effect_Field(source, 200, 200, "Dragon");
        Effect_Field(source, 200, 200, "Winged Beast");
        Effect_Field(source, 200, 200, "Thunder");
    }

    // 1283 - Mucus Yolk
    void Effect_1283_MucusYolk(CardDisplay source)
    {
        // Direct Attack. If inflicts battle damage: Gain 1000 ATK during next Standby.
        // Lógica implementada no BattleManager e OnPhaseStart.
        Debug.Log("Mucus Yolk: Efeitos configurados.");
    }

    // 1284 - Mudora
    void Effect_1284_Mudora(CardDisplay source)
    {
        // Gains 200 ATK for each Fairy in your GY.
        int count = GameManager.Instance.GetPlayerGraveyard().FindAll(c => c.race == "Fairy").Count;
        source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, count * 200, source));
    }

    // 1285 - Muka Muka
    void Effect_1285_MukaMuka(CardDisplay source)
    {
        // Gains 300 ATK/DEF for each card in your hand.
        int handCount = GameManager.Instance.GetPlayerHandData().Count;
        source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, handCount * 300, source));
        source.AddStatModifier(new StatModifier(StatModifier.StatType.DEF, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, handCount * 300, source));
    }

    // 1286 - Muko
    void Effect_1286_Muko(CardDisplay source)
    {
        // Requer hook no OnDraw ou Chain.
        Debug.Log("Muko: Cartas compradas serão descartadas (Simulado).");
    }

    // 1287 - Multiplication of Ants
    void Effect_1287_MultiplicationOfAnts(CardDisplay source)
    {
        // Tribute 1 Insect; SS 2 Army Ant Tokens.
        if (SummonManager.Instance.HasEnoughTributes(1, source.isPlayerCard)) // Check Insect
        {
            // Tribute logic...
            GameManager.Instance.SpawnToken(source.isPlayerCard, 500, 1200, "Army Ant Token");
            GameManager.Instance.SpawnToken(source.isPlayerCard, 500, 1200, "Army Ant Token");
            Debug.Log("Multiplication of Ants: 2 Tokens criados.");
        }
    }

    // 1288 - Multiply
    void Effect_1288_Multiply(CardDisplay source)
    {
        // Tribute face-up Kuriboh; SS Kuriboh Tokens to fill empty slots.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.name == "Kuriboh",
                (tribute) => {
                    GameManager.Instance.TributeCard(tribute);
                    // Fill slots
                    for(int i=0; i<5; i++) // Tenta preencher até 5
                    {
                        GameManager.Instance.SpawnToken(source.isPlayerCard, 300, 200, "Kuriboh Token");
                    }
                    Debug.Log("Multiply: Campo preenchido com Kuriboh Tokens.");
                }
            );
        }
    }

    // 1291 - Mushroom Man #2
    void Effect_1291_MushroomMan2(CardDisplay source)
    {
        // Controller loses 300 LP Standby. Pay 500 LP End Phase to switch control.
        // Lógica implementada no OnPhaseStart.
        // Vamos tratar como efeito de ignição disponível na End Phase.
        Debug.Log("Mushroom Man #2: Efeitos de fase configurados.");
    }

    // 1293 - Mustering of the Dark Scorpions
    void Effect_1293_MusteringOfTheDarkScorpions(CardDisplay source)
    {
        // If you control Don Zaloog: SS any number of Dark Scorpions from hand (1 copy each).
        if (GameManager.Instance.IsCardActiveOnField("Don Zaloog") || GameManager.Instance.IsCardActiveOnField("0516"))
        {
            List<CardData> hand = GameManager.Instance.GetPlayerHandData();
            List<CardData> scorpions = hand.FindAll(c => c.name.Contains("Dark Scorpion"));
            
            if (scorpions.Count > 0)
            {
                GameManager.Instance.OpenCardMultiSelection(scorpions, "Invocar Dark Scorpions", 1, scorpions.Count, (selected) => {
                    foreach(var c in selected)
                    {
                        GameManager.Instance.SpecialSummonFromData(c, source.isPlayerCard);
                        GameManager.Instance.RemoveCardFromHand(c, source.isPlayerCard);
                    }
                });
            }
        }
    }

    // 1294 - My Body as a Shield
    void Effect_1294_MyBodyAsAShield(CardDisplay source)
    {
        var link = GetLinkToNegate(source);
        if (link != null)
        {
            if (Effect_PayLP(source, 1500))
            {
                NegateAndDestroy(source, link);
            }
        }
        else
        {
            if (UIManager.Instance != null) UIManager.Instance.ShowMessage("Só pode ser ativada em resposta a um efeito.");
        }
    }

    // 1295 - Mysterious Guard
    void Effect_1295_MysteriousGuard(CardDisplay source)
    {
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.CurrentCardData.type.Contains("Monster") && !t.isFlipped,
                (target) => {
                    GameManager.Instance.ReturnToDeck(target, true);
                    Debug.Log($"Mysterious Guard: {target.CurrentCardData.name} retornado ao topo do deck.");
                    
                    bool hasWarrior = false;
                    if (GameManager.Instance.duelFieldUI != null) {
                        foreach(var z in GameManager.Instance.duelFieldUI.playerMonsterZones) {
                            if (z.childCount > 0) {
                                var m = z.GetChild(0).GetComponent<CardDisplay>();
                                if (m != null && m.CurrentCardData.race == "Warrior" && !m.isFlipped) hasWarrior = true;
                            }
                        }
                    }
                    
                    if (hasWarrior) {
                        SpellTrapManager.Instance.StartTargetSelection(
                            (t2) => t2.isOnField && t2.CurrentCardData.type.Contains("Monster"),
                            (target2) => { GameManager.Instance.ReturnToHand(target2); }
                        );
                    }
                }
            );
        }
    }

    // 1296 - Mysterious Puppeteer
    void Effect_1296_MysteriousPuppeteer(CardDisplay source)
    {
        // Effect: Each time a monster is Summoned, gain 500 LP.
        // Lógica implementada no OnSummonImpl.
        Debug.Log("Mysterious Puppeteer: Efeito de ganho de LP em invocação ativo.");
    }

    // 1298 - Mystic Box
    void Effect_1298_MysticBox(CardDisplay source)
    {
        // Target opp monster, target own monster. Destroy opp, give control of own.
        Debug.Log("Mystic Box: Troca e destruição.");
        if (SpellTrapManager.Instance != null)
        {
            // 1. Seleciona monstro do oponente para destruir
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && !t.isPlayerCard && t.CurrentCardData.type.Contains("Monster"),
                (oppMonster) => {
                    // 2. Seleciona monstro do jogador para dar o controle
                    SpellTrapManager.Instance.StartTargetSelection(
                        (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.type.Contains("Monster"),
                        (myMonster) => {
                            // Executa o efeito
                            Debug.Log($"Mystic Box: Destruindo {oppMonster.CurrentCardData.name} e trocando controle de {myMonster.CurrentCardData.name}.");
                            
                            // Destrói o do oponente
                            if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(oppMonster);
                            GameManager.Instance.SendToGraveyard(oppMonster.CurrentCardData, oppMonster.isPlayerCard);
                            Destroy(oppMonster.gameObject);

                            // Troca o controle do seu
                            GameManager.Instance.SwitchControl(myMonster);
                        }
                    );
                }
            );
        }
    }

    // 1301 - Mystic Lamp
    void Effect_1301_MysticLamp(CardDisplay source)
    {
        // Effect: Can attack directly.
        Debug.Log("Mystic Lamp: Ataque direto habilitado.");
        // source.canAttackDirectly = true; // Flag no CardDisplay/BattleManager
    }

    // 1302 - Mystic Plasma Zone
    void Effect_1302_MysticPlasmaZone(CardDisplay source)
    {
        Effect_Field(source, 500, -400, "", "Dark");
    }

    // 1303 - Mystic Probe
    void Effect_1303_MysticProbe(CardDisplay source)
    {
        // Effect: Negate Continuous Spell.
        if (ChainManager.Instance != null)
        {
            var lastLink = ChainManager.Instance.GetLastChainLink();
            if (lastLink != null && lastLink.cardSource.CurrentCardData.type.Contains("Spell") && lastLink.cardSource.CurrentCardData.property == "Continuous")
            {
                Debug.Log("Mystic Probe: Ativado. Magias Contínuas negadas neste turno.");
                CardEffectManager.Instance.negateContinuousSpells = true;
            }
            else
            {
                Debug.Log("Mystic Probe: Falhou. Última carta não é Magia Contínua.");
            }
        }
    }

    // 1304 - Mystic Swordsman LV2
    void Effect_1304_MysticSwordsmanLV2(CardDisplay source)
    {
        // Effect: At start of Damage Step, if attacking face-down Defense: Destroy it.
        // Lógica implementada no OnDamageCalculation.
        Debug.Log("Mystic Swordsman LV2: Efeito de destruição automática configurado.");
    }

    // 1305 - Mystic Swordsman LV4
    void Effect_1305_MysticSwordsmanLV4(CardDisplay source)
    {
        // Effect: Cannot be Normal Summoned. Start of Damage Step: Destroy face-down Defense.
        // Lógica implementada no OnDamageCalculation.
        Debug.Log("Mystic Swordsman LV4: Efeito de destruição automática configurado.");
    }

    // 1306 - Mystic Swordsman LV6
    void Effect_1306_MysticSwordsmanLV6(CardDisplay source)
    {
        // Effect: Destroy face-down Defense. If done, place on top of Deck.
        // Lógica implementada no OnDamageCalculation.
        Debug.Log("Mystic Swordsman LV6: Efeito de destruição e topo do deck configurado.");
    }

    // 1307 - Mystic Tomato
    void Effect_1307_MysticTomato(CardDisplay source)
    {
        // Effect: Destroyed by battle -> SS 1 DARK <= 1500 ATK from Deck.
        List<CardData> deck = GameManager.Instance.GetPlayerMainDeck();
        List<CardData> targets = deck.FindAll(c => c.attribute == "Dark" && c.atk <= 1500 && c.type.Contains("Monster"));
        
        if (targets.Count > 0)
        {
            GameManager.Instance.OpenCardSelection(targets, "Invocar DARK <= 1500", (selected) => {
                GameManager.Instance.SpecialSummonFromData(selected, source.isPlayerCard);
                deck.Remove(selected);
                GameManager.Instance.ShuffleDeck(source.isPlayerCard);
            });
        }
    }

    // 1308 - Mystical Beast of Serket
    void Effect_1308_MysticalBeastOfSerket(CardDisplay source)
    {
        // Effect: Destroy if no Temple. Banish destroyed monsters. Gain 500 ATK.
        if (!GameManager.Instance.IsCardActiveOnField("Temple of the Kings") && !GameManager.Instance.IsCardActiveOnField("1829"))
        {
            GameManager.Instance.SendToGraveyard(source.CurrentCardData, source.isPlayerCard);
            Destroy(source.gameObject);
        }
        // Outros efeitos no OnBattleEnd.
    }

    // 1311 - Mystical Knight of Jackal
    void Effect_1311_MysticalKnightOfJackal(CardDisplay source)
    {
        // Effect: Send destroyed monster to top of Deck.
        // Lógica implementada no OnBattleEnd.
        Debug.Log("Mystical Knight of Jackal: Efeito de topo do deck configurado.");
    }

    // 1312 - Mystical Moon
    void Effect_1312_MysticalMoon(CardDisplay source)
    {
        Effect_Equip(source, 300, 300, "Beast-Warrior");
    }

    // 1313 - Mystical Refpanel
    void Effect_1313_MysticalRefpanel(CardDisplay source)
    {
        // Activate only when a Spell Card that targets 1 player is activated. Effect applied to other player.
        if (ChainManager.Instance != null)
        {
            var lastLink = ChainManager.Instance.GetLastChainLink();
            if (lastLink != null && lastLink.cardSource.CurrentCardData.type.Contains("Spell"))
            {
                // Simulação de verificação de alvo (player)
                string id = lastLink.cardSource.CurrentCardData.id;
                if (id == "1715" || id == "1382" || id == "0654" || id == "0895") // Sparks, Ookazi, Final Flame, Hinotama
                {
                    Debug.Log("Mystical Refpanel: Redirecionando efeito para o outro jogador.");
                    CardEffectManager.Instance.redirectSpellTarget = true;
                }
                else
                {
                    Debug.Log("Mystical Refpanel: Alvo inválido (apenas magias de dano direto simples suportadas no protótipo).");
                }
            }
        }
    }

    // 1315 - Mystical Sheep #1
    void Effect_1315_MysticalSheep1(CardDisplay source)
    {
        Debug.Log("Mystical Sheep #1: Substituto de Fusão.");
    }

    // 1318 - Mystical Space Typhoon
    void Effect_1318_MysticalSpaceTyphoon(CardDisplay source)
    {
        Effect_MST(source);
    }

    // 1319 - Mystik Wok
    void Effect_1319_MystikWok(CardDisplay source)
    {
        // Effect: Tribute 1 monster; gain LP equal to ATK or DEF.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.type.Contains("Monster"),
                (tribute) => {
                    int val = Mathf.Max(tribute.currentAtk, tribute.currentDef); // Simplificado: Pega o maior
                    GameManager.Instance.TributeCard(tribute);
                    Effect_GainLP(source, val);
                    Debug.Log($"Mystik Wok: Ganhou {val} LP.");
                }
            );
        }
    }

    // 1320 - Narrow Pass
    void Effect_1320_NarrowPass(CardDisplay source)
    {
        // Activate when both players have 2 monsters or less.
        int myCount = 0;
        int oppCount = 0;
        if (GameManager.Instance.duelFieldUI != null)
        {
            foreach(var z in GameManager.Instance.duelFieldUI.playerMonsterZones) if(z.childCount > 0) myCount++;
            foreach(var z in GameManager.Instance.duelFieldUI.opponentMonsterZones) if(z.childCount > 0) oppCount++;
        }

        if (myCount <= 2 && oppCount <= 2)
        {
            Debug.Log("Narrow Pass: Ativado. Limite de invocações aplicado.");
            if (SummonManager.Instance != null)
            {
                SummonManager.Instance.narrowPassActive = true;
                SummonManager.Instance.narrowPassSummonCount = 0;
            }
        }
        else
        {
            Debug.Log("Narrow Pass: Condição não atendida (ambos devem ter <= 2 monstros).");
        }
    }

    // 1322 - Necklace of Command
    void Effect_1322_NecklaceOfCommand(CardDisplay source)
    {
        // Equip Spell. Effect triggers when destroyed.
        Effect_Equip(source, 0, 0);
        Debug.Log("Necklace of Command: Equipado. (Efeito ao ser destruído configurado).");
    }

    // 1324 - Necrovalley
    void Effect_1324_Necrovalley(CardDisplay source)
    {
        Effect_Field(source, 500, 500, "Gravekeeper's");
        Debug.Log("Necrovalley: Bloqueio de GY ativo (Passivo).");
    }

    // 1325 - Needle Ball
    void Effect_1325_NeedleBall(CardDisplay source)
    {
        // FLIP: Pay 2000 LP; inflict 1000 damage.
        if (Effect_PayLP(source, 2000))
        {
            Effect_DirectDamage(source, 1000);
        }
    }

    // 1326 - Needle Burrower
    void Effect_1326_NeedleBurrower(CardDisplay source)
    {
        // Effect: If destroys monster by battle and sends to GY: Inflict damage = Level x 500.
        // Lógica implementada no OnBattleEnd.
        Debug.Log("Needle Burrower: Efeito de dano configurado.");
    }

    // 1327 - Needle Ceiling
    void Effect_1327_NeedleCeiling(CardDisplay source)
    {
        // Effect: If 4 or more monsters on field: Destroy all face-up monsters.
        int count = 0;
        if (GameManager.Instance.duelFieldUI != null)
        {
            foreach(var z in GameManager.Instance.duelFieldUI.playerMonsterZones) if(z.childCount > 0) count++;
            foreach(var z in GameManager.Instance.duelFieldUI.opponentMonsterZones) if(z.childCount > 0) count++;
        }

        if (count >= 4)
        {
            List<CardDisplay> toDestroy = new List<CardDisplay>();
            if (GameManager.Instance.duelFieldUI != null)
            {
                List<CardDisplay> all = new List<CardDisplay>();
                CollectMonsters(GameManager.Instance.duelFieldUI.playerMonsterZones, all);
                CollectMonsters(GameManager.Instance.duelFieldUI.opponentMonsterZones, all);
                foreach(var m in all) if(!m.isFlipped) toDestroy.Add(m);
            }
            DestroyCards(toDestroy, source.isPlayerCard);
            Debug.Log("Needle Ceiling: Monstros face-up destruídos.");
        }
        else
        {
            Debug.Log("Needle Ceiling: Requer 4 ou mais monstros.");
        }
    }

    // 1328 - Needle Wall
    void Effect_1328_NeedleWall(CardDisplay source)
    {
        // Continuous Trap. Standby Phase logic.
        // Lógica implementada no OnPhaseStart.
    }

    // 1329 - Needle Worm
    void Effect_1329_NeedleWorm(CardDisplay source)
    {
        // FLIP: Send top 5 cards of opponent's Deck to GY.
        GameManager.Instance.MillCards(!source.isPlayerCard, 5);
    }

    // 1330 - Negate Attack
    void Effect_1330_NegateAttack(CardDisplay source)
    {
        // Target attacking monster; negate attack, end Battle Phase.
        if (BattleManager.Instance != null && BattleManager.Instance.currentAttacker != null)
        {
            Debug.Log("Negate Attack: Ataque negado e Battle Phase encerrada.");
            BattleManager.Instance.CancelCurrentAttack();
            // Lógica de encerrar fase
            if (PhaseManager.Instance != null) PhaseManager.Instance.ChangePhase(GamePhase.Main2);
        }
    }

    // 1331 - Neko Mane King
    void Effect_1331_NekoManeKing(CardDisplay source)
    {
        // Effect: Opponent's turn, sent to GY by opponent's effect -> End Turn.
        // Lógica implementada no OnCardSentToGraveyard.
        Debug.Log("Neko Mane King: Efeito de encerrar turno configurado.");
    }

    // 1338 - Newdoria
    void Effect_1338_Newdoria(CardDisplay source)
    {
        // Effect: Destroyed by battle -> Destroy 1 monster.
        // Lógica implementada no OnCardSentToGraveyard.
        Debug.Log("Newdoria: Efeito de destruição configurado.");
    }

    // 1339 - Night Assailant
    void Effect_1339_NightAssailant(CardDisplay source)
    {
        // FLIP: Destroy 1 monster opp controls.
        // Sent from hand to GY: Return Flip monster from GY to hand.
        if (source.isFlipped)
        {
            Effect_FlipDestroy(source, TargetType.Monster);
        }
        // Lógica de mão no OnCardDiscarded.
    }

    // 1341 - Nightmare Horse
    void Effect_1341_NightmareHorse(CardDisplay source)
    {
        source.canAttackDirectly = true;
    }

    // 1342 - Nightmare Penguin
    void Effect_1342_NightmarePenguin(CardDisplay source)
    {
        // Water +200 ATK. FLIP: Return 1 card opp controls to hand.
        Effect_Field(source, 200, 0, "", "Water");
        if (source.isFlipped)
        {
            if (SpellTrapManager.Instance != null)
            {
                SpellTrapManager.Instance.StartTargetSelection(
                    (t) => t.isOnField && !t.isPlayerCard,
                    (t) => GameManager.Instance.ReturnToHand(t)
                );
            }
        }
    }

    // 1344 - Nightmare Wheel
    void Effect_1344_NightmareWheel(CardDisplay source)
    {
        // Target 1 monster; cannot attack/change pos. Standby: 500 damage.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && !t.isPlayerCard && t.CurrentCardData.type.Contains("Monster"),
                (t) => {
                    Debug.Log($"Nightmare Wheel: Alvejando {t.CurrentCardData.name}.");
                    GameManager.Instance.CreateCardLink(source, t, CardLink.LinkType.Continuous);
                    // Lock logic in BattleManager
                }
            );
        }
    }

    // 1345 - Nightmare's Steelcage
    void Effect_1345_NightmaresSteelcage(CardDisplay source)
    {
        // No attacks for 2 turns. Destroy after 2 turns.
        Debug.Log("Nightmare's Steelcage: Ativado. Contagem de turnos iniciada.");
        source.spellCounters = 2; // Usa contadores para rastrear turnos
    }

    // 1346 - Nimble Momonga
    void Effect_1346_NimbleMomonga(CardDisplay source)
    {
        // Destroyed by battle: Gain 1000 LP, SS up to 2 from Deck.
        // Lógica implementada no OnCardSentToGraveyard.
        Debug.Log("Nimble Momonga: Efeito de cura e invocação configurado.");
    }

    // 1348 - Ninja Grandmaster Sasuke
    void Effect_1348_NinjaGrandmasterSasuke(CardDisplay source)
    {
        // Attack face-up Defense -> Destroy.
        // Lógica implementada no OnDamageCalculation.
        Debug.Log("Ninja Grandmaster Sasuke: Efeito de destruição configurado.");
    }

    // 1349 - Ninjitsu Art of Decoy
    void Effect_1349_NinjitsuArtOfDecoy(CardDisplay source)
    {
        // Target Ninja; cannot be destroyed by battle.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.name.Contains("Ninja"),
                (t) => {
                    GameManager.Instance.CreateCardLink(source, t, CardLink.LinkType.Equipment);
                    Debug.Log($"Ninjitsu Art of Decoy: {t.CurrentCardData.name} protegido de batalha.");
                }
            );
        }
    }

    // 1350 - Ninjitsu Art of Transformation
    void Effect_1350_NinjitsuArtOfTransformation(CardDisplay source)
    {
        // Tribute Ninja; SS Beast/Winged Beast/Insect Lv <= Level+3.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.name.Contains("Ninja"),
                (tribute) => {
                    int limit = tribute.CurrentCardData.level + 3;
                    GameManager.Instance.TributeCard(tribute);
                    
                    List<CardData> deck = GameManager.Instance.GetPlayerMainDeck();
                    List<CardData> targets = deck.FindAll(c => (c.race == "Beast" || c.race == "Winged Beast" || c.race == "Insect") && c.level <= limit);
                    
                    if (targets.Count > 0)
                    {
                        GameManager.Instance.OpenCardSelection(targets, "Invocar Transformação", (selected) => {
                            GameManager.Instance.SpecialSummonFromData(selected, source.isPlayerCard);
                        });
                    }
                }
            );
        }
    }

    // 1351 - Nitro Unit
    void Effect_1351_NitroUnit(CardDisplay source)
    {
        // Equip only to opponent's monster. If destroyed by battle -> Damage = ATK.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && !t.isPlayerCard && t.CurrentCardData.type.Contains("Monster"),
                (target) => {
                    GameManager.Instance.CreateCardLink(source, target, CardLink.LinkType.Equipment);
                    Debug.Log($"Nitro Unit: Equipado em {target.CurrentCardData.name}.");
                }
            );
        }
    }

    // 1353 - Nobleman of Crossout
    void Effect_1353_NoblemanOfCrossout(CardDisplay source)
    {
        // Target face-down monster; destroy and banish. If Flip, banish copies from Decks.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.CurrentCardData.type.Contains("Monster") && t.isFlipped, // Face-down (isFlipped=true)
                (target) => {
                    target.RevealCard(); // Revela para verificar se é Flip
                    bool isFlip = target.CurrentCardData.description.Contains("FLIP:");
                    
                    Debug.Log($"Nobleman of Crossout: Banindo {target.CurrentCardData.name}.");
                    GameManager.Instance.BanishCard(target);

                    if (isFlip)
                    {
                        Debug.Log("Nobleman of Crossout: Era monstro Flip. Banindo cópias dos Decks.");
                        string targetName = target.CurrentCardData.name;
                        List<CardData> pDeck = GameManager.Instance.GetPlayerMainDeck();
                        List<CardData> oDeck = GameManager.Instance.GetOpponentMainDeck();
                        foreach (var c in new List<CardData>(pDeck)) {
                            if (c.name == targetName) { GameManager.Instance.RemoveFromPlay(c, true); pDeck.Remove(c); }
                        }
                        foreach (var c in new List<CardData>(oDeck)) {
                            if (c.name == targetName) { GameManager.Instance.RemoveFromPlay(c, false); oDeck.Remove(c); }
                        }
                        GameManager.Instance.ShuffleDeck(true);
                        GameManager.Instance.ShuffleDeck(false);
                    }
                }
            );
        }
    }

    // 1354 - Nobleman of Extermination
    void Effect_1354_NoblemanOfExtermination(CardDisplay source)
    {
        // Target face-down S/T; destroy and banish. If Trap, banish copies from Decks.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && (t.CurrentCardData.type.Contains("Spell") || t.CurrentCardData.type.Contains("Trap")) && t.isFlipped,
                (target) => {
                    target.RevealCard();
                    bool isTrap = target.CurrentCardData.type.Contains("Trap");
                    
                    Debug.Log($"Nobleman of Extermination: Banindo {target.CurrentCardData.name}.");
                    GameManager.Instance.BanishCard(target);

                    if (isTrap)
                    {
                        Debug.Log("Nobleman of Extermination: Era Armadilha. Banindo cópias dos Decks.");
                        string targetName = target.CurrentCardData.name;
                        List<CardData> pDeck = GameManager.Instance.GetPlayerMainDeck();
                        List<CardData> oDeck = GameManager.Instance.GetOpponentMainDeck();
                        foreach (var c in new List<CardData>(pDeck)) {
                            if (c.name == targetName) { GameManager.Instance.RemoveFromPlay(c, true); pDeck.Remove(c); }
                        }
                        foreach (var c in new List<CardData>(oDeck)) {
                            if (c.name == targetName) { GameManager.Instance.RemoveFromPlay(c, false); oDeck.Remove(c); }
                        }
                        GameManager.Instance.ShuffleDeck(true);
                        GameManager.Instance.ShuffleDeck(false);
                    }
                }
            );
        }
    }

    // 1355 - Nobleman-Eater Bug
    void Effect_1355_NoblemanEaterBug(CardDisplay source)
    {
        if (SpellTrapManager.Instance != null) {
            List<CardDisplay> all = new List<CardDisplay>();
            if (GameManager.Instance.duelFieldUI != null) {
                CollectMonsters(GameManager.Instance.duelFieldUI.playerMonsterZones, all);
                CollectMonsters(GameManager.Instance.duelFieldUI.opponentMonsterZones, all);
            }
            if (all.Count > 0) {
                SpellTrapManager.Instance.StartTargetSelection((t) => t.isOnField && t.CurrentCardData.type.Contains("Monster"), (t1) => {
                    if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(t1);
                    GameManager.Instance.SendToGraveyard(t1.CurrentCardData, t1.isPlayerCard);
                    Destroy(t1.gameObject);
                    all.Remove(t1);
                    if (all.Count > 0 && UIManager.Instance != null) {
                        UIManager.Instance.ShowConfirmation("Nobleman-Eater Bug: Destruir mais um monstro?", () => {
                            SpellTrapManager.Instance.StartTargetSelection((t2) => t2.isOnField && t2.CurrentCardData.type.Contains("Monster"), (t3) => {
                                if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(t3);
                                GameManager.Instance.SendToGraveyard(t3.CurrentCardData, t3.isPlayerCard);
                                Destroy(t3.gameObject);
                            });
                        }, null);
                    }
                });
            }
        }
    }

    // 1356 - Non Aggression Area
    void Effect_1356_NonAggressionArea(CardDisplay source)
    {
        // Standby Phase, Discard 1. Opponent cannot Summon next turn.
        // Lógica implementada no OnPhaseStart.
        Debug.Log("Non Aggression Area: Oponente não pode invocar no próximo turno.");
    }

    // 1357 - Non-Spellcasting Area
    void Effect_1357_NonSpellcastingArea(CardDisplay source)
    {
        // Face-up non-Effect Monsters are unaffected by Spell effects.
        Debug.Log("Non-Spellcasting Area: Imunidade para Monstros Normais (Passivo).");
    }

    // 1358 - Novox's Prayer
    void Effect_1358_NovoxsPrayer(CardDisplay source)
    {
        Debug.Log("Novox's Prayer: Ritual para Skull Guardian.");
    }

    // 1359 - Nubian Guard
    void Effect_1359_NubianGuard(CardDisplay source)
    {
        // If inflicts battle damage: Return 1 Continuous Spell from GY to top of Deck.
        // Lógica implementada no OnDamageDealtImpl.
        Debug.Log("Nubian Guard: Efeito de reciclagem configurado.");
    }

    // 1360 - Numinous Healer
    void Effect_1360_NuminousHealer(CardDisplay source)
    {
        int copies = source.isPlayerCard ? GameManager.Instance.GetPlayerGraveyard().FindAll(c => c.name == "Numinous Healer").Count : GameManager.Instance.GetOpponentGraveyard().FindAll(c => c.name == "Numinous Healer").Count;
        Effect_GainLP(source, 1000 + (copies * 500));
    }

    // 1361 - Nutrient Z
    void Effect_1361_NutrientZ(CardDisplay source)
    {
        // When taking 2000+ battle damage: Gain 4000 LP before damage.
        Effect_GainLP(source, 4000);
    }

    // 1362 - Nuvia the Wicked
    void Effect_1362_NuviaTheWicked(CardDisplay source)
    {
        // If Normal Summoned, destroy self. ATK -200 per opponent monster.
        // Auto-destruição implementada no OnSummonImpl.
        // Debuff:
        int oppCount = 0;
        if (GameManager.Instance.duelFieldUI != null)
            foreach(var z in GameManager.Instance.duelFieldUI.opponentMonsterZones) if(z.childCount > 0) oppCount++;
        
        source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, oppCount * -200, source));
    }

    // 1364 - Obnoxious Celtic Guard
    void Effect_1364_ObnoxiousCelticGuard(CardDisplay source)
    {
        // Cannot be destroyed by battle with monster ATK >= 1900.
        // Lógica implementada no BattleManager.
    }

    // 1365 - Ocean Dragon Lord - Neo-Daedalus
    void Effect_1365_OceanDragonLordNeoDaedalus(CardDisplay source)
    {
        // Send Umi to GY; send all cards in both hands and field to GY.
        if (GameManager.Instance.IsCardActiveOnField("2015") || GameManager.Instance.IsCardActiveOnField("0013")) // Umi
        {
            Debug.Log("Neo-Daedalus: Enviando tudo para o GY!");
            // Lógica de limpar mãos e campo (exceto este card)
            GameManager.Instance.DiscardHand(true);
            GameManager.Instance.DiscardHand(false);
            DestroyAllMonsters(true, true); // Deveria filtrar source
            Effect_HeavyStorm(source);
        }
    }

    // 1368 - Offerings to the Doomed
    void Effect_1368_OfferingsToTheDoomed(CardDisplay source)
    {
        // Target 1 face-up monster; destroy it. Skip next Draw Phase.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.CurrentCardData.type.Contains("Monster") && !t.isFlipped,
                (target) => {
                    if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(target);
                    GameManager.Instance.SendToGraveyard(target.CurrentCardData, target.isPlayerCard);
                    Destroy(target.gameObject);
                    
                    if (SpellTrapManager.Instance != null) SpellTrapManager.Instance.RegisterSkipDraw();
                    Debug.Log("Offerings to the Doomed: Alvo destruído. Próximo Draw pulado.");
                }
            );
        }
    }

    // 1371 - Ojama Delta Hurricane
    void Effect_1371_OjamaDeltaHurricane(CardDisplay source)
    {
        // If Green, Yellow, Black on field: Destroy all cards opp controls.
        bool hasG = GameManager.Instance.IsCardActiveOnField("Ojama Green") || GameManager.Instance.IsCardActiveOnField("1372");
        bool hasY = GameManager.Instance.IsCardActiveOnField("Ojama Yellow") || GameManager.Instance.IsCardActiveOnField("1375");
        bool hasB = GameManager.Instance.IsCardActiveOnField("Ojama Black") || GameManager.Instance.IsCardActiveOnField("1370");

        if (hasG && hasY && hasB)
        {
            Debug.Log("Ojama Delta Hurricane!!: Destruindo campo do oponente.");
            DestroyAllMonsters(true, false);
            Effect_HarpiesFeatherDuster(source);
        }
    }

    // 1373 - Ojama King
    void Effect_1373_OjamaKing(CardDisplay source)
    {
        if (GameManager.Instance.duelFieldUI == null || !source.isOnField) return;

        Transform[] oppZones = source.isPlayerCard ? GameManager.Instance.duelFieldUI.opponentMonsterZones : GameManager.Instance.duelFieldUI.playerMonsterZones;
        List<Transform> availableZones = new List<Transform>();
        
        foreach (var z in oppZones) 
            if (z.childCount == 0 && !GameManager.Instance.duelFieldUI.IsZoneBlocked(z)) availableZones.Add(z);

        int zonesToBlock = Mathf.Min(3, availableZones.Count);
        if (zonesToBlock > 0)
        {
            List<Transform> blocked = new List<Transform>();
            for (int i = 0; i < zonesToBlock; i++)
            {
                int rnd = Random.Range(0, availableZones.Count);
                Transform chosen = availableZones[rnd];
                GameManager.Instance.duelFieldUI.BlockZone(chosen);
                blocked.Add(chosen);
                availableZones.RemoveAt(rnd);
            }
            CardEffectManager.Instance.blockedZonesByCard[source] = blocked;
            Debug.Log($"Ojama King: {zonesToBlock} zonas do oponente bloqueadas.");
        }
    }

    // 1374 - Ojama Trio
    void Effect_1374_OjamaTrio(CardDisplay source)
    {
        int emptyZones = 0;
        if (GameManager.Instance.duelFieldUI != null) {
            Transform[] oppZones = source.isPlayerCard ? GameManager.Instance.duelFieldUI.opponentMonsterZones : GameManager.Instance.duelFieldUI.playerMonsterZones;
            foreach (var z in oppZones) if (z.childCount == 0 && !GameManager.Instance.duelFieldUI.IsZoneBlocked(z)) emptyZones++;
        }
        
        if (emptyZones >= 3) {
            for(int i=0; i<3; i++) GameManager.Instance.SpawnToken(!source.isPlayerCard, 0, 1000, "Ojama Token", 2, "Beast", "Light");
        } else {
            if (UIManager.Instance != null) UIManager.Instance.ShowMessage("O oponente não tem 3 zonas vazias.");
        }
    }

    // 1376 - Old Vindictive Magician
    void Effect_1376_OldVindictiveMagician(CardDisplay source)
    {
        // FLIP: Destroy 1 monster.
        Effect_FlipDestroy(source, TargetType.Monster);
    }

    // 1377 - Ominous Fortunetelling
    void Effect_1377_OminousFortunetelling(CardDisplay source)
    {
        // During your Standby Phase, select 1 random card from your opponent's hand. Call the type...
        // Logic handled in OnPhaseStart (CardEffectManager_Impl.cs)
        Debug.Log("Ominous Fortunetelling: Efeito de adivinhação na Standby Phase configurado.");
    }

    // 1381 - Ooguchi
    void Effect_1381_Ooguchi(CardDisplay source)
    {
        source.canAttackDirectly = true;
    }

    // 1382 - Ookazi
    void Effect_1382_Ookazi(CardDisplay source)
    {
        // Inflict 800 damage.
        Effect_DirectDamage(source, 800);
    }

    // 1384 - Opti-Camouflage Armor
    void Effect_1384_OptiCamouflageArmor(CardDisplay source)
    {
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.CurrentCardData.type.Contains("Monster") && t.CurrentCardData.level == 1 && !t.isFlipped,
                (target) => {
                    target.canAttackDirectly = true;
                    GameManager.Instance.CreateCardLink(source, target, CardLink.LinkType.Equipment);
                }
            );
        }
    }

    // 1387 - Ordeal of a Traveler
    void Effect_1387_OrdealOfATraveler(CardDisplay source)
    {
        if (BattleManager.Instance == null || BattleManager.Instance.currentAttacker == null) return;
        CardDisplay attacker = BattleManager.Instance.currentAttacker;
        if (attacker.isPlayerCard == source.isPlayerCard) return; // Só ativa quando oponente ataca

        List<CardData> myHand = source.isPlayerCard ? GameManager.Instance.GetPlayerHandData() : GameManager.Instance.GetOpponentHandData();
        if (myHand.Count == 0) return;

        CardData picked = myHand[Random.Range(0, myHand.Count)];
        List<string> options = new List<string> { "Monster", "Spell", "Trap" };

        if (attacker.isPlayerCard && MultipleChoiceUI.Instance != null) { // Oponente (Jogador) adivinha
            MultipleChoiceUI.Instance.Show(options, "Ordeal of a Traveler: Adivinhe o Tipo!", 1, 1, (selected) => {
                if (selected.Count > 0) {
                    bool correct = picked.type.Contains(selected[0]);
                    if (!correct) GameManager.Instance.ReturnToHand(attacker);
                }
            });
        }
        else { // Oponente (IA) adivinha
            string guess = options[Random.Range(0, options.Count)];
            bool correct = picked.type.Contains(guess);
            if (!correct) GameManager.Instance.ReturnToHand(attacker);
        }
    }

    // 1386 - Orca Mega-Fortress of Darkness
    void Effect_1386_OrcaMegaFortressOfDarkness(CardDisplay source)
    {
        List<string> options = new List<string>();
        bool hasTorpedo = false;
        bool hasCannonball = false;

        if (GameManager.Instance.duelFieldUI != null)
        {
            foreach (var z in GameManager.Instance.duelFieldUI.playerMonsterZones)
            {
                if (z.childCount > 0)
                {
                    var m = z.GetChild(0).GetComponent<CardDisplay>();
                    if (m != null && m.CurrentCardData.name == "Torpedo Fish") hasTorpedo = true;
                    if (m != null && m.CurrentCardData.name == "Cannonball Spear Shellfish") hasCannonball = true;
                }
            }
        }

        if (hasTorpedo) options.Add("Tributar Torpedo Fish para destruir 1 monstro");
        if (hasCannonball) options.Add("Tributar Cannonball Spear Shellfish para destruir 1 S/T");

        if (options.Count == 0)
        {
            UIManager.Instance.ShowMessage("Você não tem os monstros corretos para tributar.");
            return;
        }

        if (MultipleChoiceUI.Instance != null)
        {
            MultipleChoiceUI.Instance.Show(options, "Orca Mega-Fortress of Darkness", 1, 1, (selected) => {
                string opt = selected[0];
                if (opt.Contains("Torpedo"))
                {
                    if (SpellTrapManager.Instance != null) {
                        SpellTrapManager.Instance.StartTargetSelection((t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.name == "Torpedo Fish", (tribute) => {
                            GameManager.Instance.TributeCard(tribute);
                            SpellTrapManager.Instance.StartTargetSelection((target) => target.isOnField && target.CurrentCardData.type.Contains("Monster"), (target) => {
                                if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(target);
                                GameManager.Instance.SendToGraveyard(target.CurrentCardData, target.isPlayerCard);
                                Destroy(target.gameObject);
                            });
                        });
                    }
                }
                else if (opt.Contains("Cannonball"))
                {
                    if (SpellTrapManager.Instance != null) {
                        SpellTrapManager.Instance.StartTargetSelection((t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.name == "Cannonball Spear Shellfish", (tribute) => {
                            GameManager.Instance.TributeCard(tribute);
                            SpellTrapManager.Instance.StartTargetSelection((target) => target.isOnField && (target.CurrentCardData.type.Contains("Spell") || target.CurrentCardData.type.Contains("Trap")), (target) => {
                                if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(target);
                                GameManager.Instance.SendToGraveyard(target.CurrentCardData, target.isPlayerCard);
                                Destroy(target.gameObject);
                            });
                        });
                    }
                }
            });
        }
    }

    // 1388 - Order to Charge
    void Effect_1388_OrderToCharge(CardDisplay source)
    {
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.type.Contains("Normal") && !t.CurrentCardData.race.Contains("Token"),
                (tribute) => {
                    GameManager.Instance.TributeCard(tribute);
                    SpellTrapManager.Instance.StartTargetSelection(
                        (target) => target.isOnField && !target.isPlayerCard && target.CurrentCardData.type.Contains("Monster"),
                        (target) => {
                            if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(target);
                            GameManager.Instance.SendToGraveyard(target.CurrentCardData, target.isPlayerCard);
                            Destroy(target.gameObject);
                        }
                    );
                }
            );
        }
    }

    // 1389 - Order to Smash
    void Effect_1389_OrderToSmash(CardDisplay source)
    {
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.type.Contains("Normal") && t.CurrentCardData.level <= 2 && !t.CurrentCardData.race.Contains("Token"),
                (tribute) => {
                    GameManager.Instance.TributeCard(tribute);
                    List<CardDisplay> oppST = new List<CardDisplay>();
                    if (GameManager.Instance.duelFieldUI != null) {
                        CollectCards(GameManager.Instance.duelFieldUI.opponentSpellZones, oppST);
                        CollectCards(new Transform[] { GameManager.Instance.duelFieldUI.opponentFieldSpell }, oppST);
                    }
                    if (oppST.Count > 0) {
                        int max = Mathf.Min(2, oppST.Count);
                        for(int i=0; i<max; i++) {
                            if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(oppST[i]);
                            GameManager.Instance.SendToGraveyard(oppST[i].CurrentCardData, oppST[i].isPlayerCard);
                            Destroy(oppST[i].gameObject);
                        }
                    }
                }
            );
        }
    }

    // 1392 - Otohime
    void Effect_1392_Otohime(CardDisplay source)
    {
        if (source.summonedThisTurn || source.isFlipped)
        {
            if (SpellTrapManager.Instance != null)
            {
                SpellTrapManager.Instance.StartTargetSelection(
                    (t) => t.isOnField && !t.isPlayerCard && !t.isFlipped,
                    (target) => { target.ChangePosition(); }
                );
            }
        }
    }

    // 1393 - Outstanding Dog Marron
    void Effect_1393_OutstandingDogMarron(CardDisplay source)
    {
        Debug.Log("Outstanding Dog Marron: Retorno ao Deck configurado no OnCardSentToGraveyard.");
    }

    // 1395 - Overpowering Eye
    void Effect_1395_OverpoweringEye(CardDisplay source)
    {
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.race == "Zombie" && t.currentAtk <= 2000,
                (target) => { target.canAttackDirectly = true; }
            );
        }
    }

    // 1396 - Owner's Seal
    void Effect_1396_OwnersSeal(CardDisplay source)
    {
        Effect_1515_RemoveBrainwashing(source); 
    }

    // 1397 - Painful Choice
    void Effect_1397_PainfulChoice(CardDisplay source)
    {
        List<CardData> deck = GameManager.Instance.GetPlayerMainDeck();
        if (deck.Count >= 5)
        {
            GameManager.Instance.OpenCardMultiSelection(deck, "Selecione 5 cartas para revelar", 5, 5, (selection) => {
                if (selection.Count == 5)
                {
                    GameManager.Instance.OpenCardSelection(selection, "Oponente Escolhe para SUA Mão", (selected) => {
                        GameManager.Instance.AddCardToHand(selected, source.isPlayerCard);
                        selection.Remove(selected);
                        deck.Remove(selected);
                        foreach(CardData card in selection) {
                            deck.Remove(card);
                            GameManager.Instance.SendToGraveyard(card, source.isPlayerCard);
                        }
                        GameManager.Instance.ShuffleDeck(source.isPlayerCard);
                    });
                }
            });
        }
    }

    // 1398 - Paladin of White Dragon
    void Effect_1398_PaladinOfWhiteDragon(CardDisplay source)
    {
        // Tribute to SS Blue-Eyes.
        Debug.Log("Paladin of White Dragon: Ritual. Tributa para invocar Blue-Eyes.");
    }

    // 1400 - Pandemonium
    void Effect_1400_Pandemonium(CardDisplay source)
    {
        Debug.Log("Pandemonium: Busca resolvida no trigger OnCardSentToGraveyard.");
    }

    // 1401 - Pandemonium Watchbear
    void Effect_1401_PandemoniumWatchbear(CardDisplay source)
    {
        // As long as this card remains face-up on your side of the field, "Pandemonium" on your side of the field is not destroyed by your opponent's card effects.
        // Lógica passiva. O sistema de destruição (DestroyCards) deveria checar essa proteção.
        // Como não temos um sistema de "Pre-Destroy Check" robusto, deixamos o log e assumimos que o oponente (IA) não alveja Pandemonium se isso estiver em campo.
        Debug.Log("Pandemonium Watchbear: Proteção ativa para Pandemonium contra efeitos do oponente.");
    }

    // 1402 - Panther Warrior
    void Effect_1402_PantherWarrior(CardDisplay source)
    {
        Debug.Log("Panther Warrior: Requer tributo para atacar (Resolvido no OnAttackDeclaredRoutine).");
    }

    // 1403 - Paralyzing Potion
    void Effect_1403_ParalyzingPotion(CardDisplay source)
    {
        // Equip only to a monster that is not a Machine-Type monster. The equipped monster cannot attack.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && !t.CurrentCardData.type.Contains("Machine"),
                (t) => {
                    t.cannotAttackThisTurn = true;
                    GameManager.Instance.CreateCardLink(source, t, CardLink.LinkType.Continuous);
                    Debug.Log($"Paralyzing Potion: {t.CurrentCardData.name} não pode atacar.");
                }
            );
        }
    }

    // 1404 - Parasite Paracide
    void Effect_1404_ParasiteParacide(CardDisplay source)
    {
        // FLIP: Shuffle this card into your opponent's Deck.
        List<CardData> oppDeck = GameManager.Instance.GetOpponentMainDeck();
        oppDeck.Add(source.CurrentCardData);
        GameManager.Instance.ShuffleDeck(false);
        
        // Remove from current field (Visual)
        Destroy(source.gameObject);
        Debug.Log("Parasite Paracide: Embaralhado no deck do oponente.");
    }

    // 1406 - Patrician of Darkness
    void Effect_1406_PatricianOfDarkness(CardDisplay source)
    {
        // All monsters your opponent controls must attack this card, if able.
        // Lógica implementada no BattleManager.
        Debug.Log("Patrician of Darkness: Você escolhe os alvos dos ataques do oponente.");
        if (BattleManager.Instance != null) BattleManager.Instance.patricianOfDarknessActive = true;
    }

    // 1407 - Patroid
    void Effect_1407_Patroid(CardDisplay source)
    {
        if (Effect_PayLP(source, 1000))
        {
            if (SpellTrapManager.Instance != null)
            {
                SpellTrapManager.Instance.StartTargetSelection(
                    (t) => t.isOnField && t.isFlipped,
                    (t) => {
                        t.RevealCard();
                        if (UIManager.Instance != null) {
                            UIManager.Instance.ShowConfirmation($"A carta setada é: {t.CurrentCardData.name}. Escondê-la novamente?", () => { t.ShowBack(); });
                        } else { t.ShowBack(); }
                    }
                );
            }
        }
    }

    // 1408 - Patrol Robo
    void Effect_1408_PatrolRobo(CardDisplay source)
    {
        // Paga 800. Roll die. +Dice * 100.
        if (Effect_PayLP(source, 1000))
        {
            GameManager.Instance.TossCoin(1, (heads) => {
                int roll = Random.Range(1, 7);
                Debug.Log($"Patrol Robo: Rolou {roll}. +{roll * 100} ATK/DEF.");
                // Implementa lógica para aumentar ATK e DEF
                source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, roll * 100, source));
                source.AddStatModifier(new StatModifier(StatModifier.StatType.DEF, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, roll * 100, source));
            });
        }
    }

    // 1410 - Penalty Game!
    void Effect_1410_PenaltyGame(CardDisplay source)
    {
        // When your opponent has 4 cards in their hand: Activate 1 of these effects.
        // 1. Opponent cannot draw during next Draw Phase.
        // 2. Opponent cannot activate Spell/Trap Cards this turn.
        List<CardData> oppHand = GameManager.Instance.GetOpponentHandData();
        if (oppHand.Count == 4)
        {
            if (UIManager.Instance != null)
            {
                UIManager.Instance.ShowConfirmation("Escolha: Impedir Saque (Sim) ou Impedir S/T (Não)?", 
                    () => {
                        Debug.Log("Penalty Game: Oponente não compra no próximo turno.");
                        if (PhaseManager.Instance != null) PhaseManager.Instance.RegisterSkipNextPhase(false, GamePhase.Draw);
                    },
                    () => {
                        Debug.Log("Penalty Game: Oponente não ativa S/T neste turno.");
                        // Adicionar flag global no GameManager ou SpellTrapManager
                        // SpellTrapManager.Instance.blockOpponentST = true; 
                    }
                );
            }
        }
        else
        {
            Debug.Log("Penalty Game: Oponente precisa ter exatamente 4 cartas na mão.");
        }
    }

    void Effect_1412_PenguinKnight(CardDisplay source)
    {
        // If this card is sent to the Graveyard as a result of battle, shuffle all the cards in your Graveyard into your Deck.
        // Lógica implementada no OnCardSentToGraveyard.
    }

    void Effect_1413_PenguinSoldier(CardDisplay source)
    {
        if (SpellTrapManager.Instance != null) {
            List<CardDisplay> all = new List<CardDisplay>();
            if (GameManager.Instance.duelFieldUI != null) {
                CollectMonsters(GameManager.Instance.duelFieldUI.playerMonsterZones, all);
                CollectMonsters(GameManager.Instance.duelFieldUI.opponentMonsterZones, all);
            }
            if (all.Count > 0) {
                SpellTrapManager.Instance.StartTargetSelection((t) => t.isOnField && t.CurrentCardData.type.Contains("Monster"), (t1) => {
                    GameManager.Instance.ReturnToHand(t1);
                    all.Remove(t1);
                    if (all.Count > 0 && UIManager.Instance != null) {
                        UIManager.Instance.ShowConfirmation("Penguin Soldier: Retornar mais um monstro?", () => {
                            SpellTrapManager.Instance.StartTargetSelection((t2) => t2.isOnField && t2.CurrentCardData.type.Contains("Monster"), (t3) => {
                                GameManager.Instance.ReturnToHand(t3);
                            });
                        }, null);
                    }
                });
            }
        }
    }

    void Effect_1414_PenumbralSoldierLady(CardDisplay source)
    {
        // If this card attacks a monster with the LIGHT Attribute, increase the ATK of this card by 1000 points during damage calculation only.
        // Lógica implementada no OnDamageCalculation.
    }

    void Effect_1416_PerfectMachineKing(CardDisplay source)
    {
        // Increase the ATK and DEF of this card by 500 points for each Machine-Type monster on the field.
        Debug.Log("Perfect Machine King: Aumenta o ATK e DEF em 500 para cada monstro Machine-Type no campo.");
    }

    void Effect_1417_PerfectlyUltimateGreatMoth(CardDisplay source)
    {
        // Special Summoned by tributing "Petit Moth" equipped with "Cocoon of Evolution" for 4 or more of your turns.
        if (!source.isOnField)
        {
             if (SpellTrapManager.Instance != null) {
                 SpellTrapManager.Instance.StartTargetSelection(
                     (t) => t.isOnField && t.isPlayerCard && t.CurrentCardData.name == "Petit Moth" && CardEffectManager.Instance.GetEquippedCards(t).Exists(e => e.CurrentCardData.name == "Cocoon of Evolution" && e.turnCounter >= 6),
                     (t) => {
                         GameManager.Instance.TributeCard(t);
                         GameManager.Instance.SpecialSummonFromData(source.CurrentCardData, source.isPlayerCard);
                         GameManager.Instance.RemoveCardFromHand(source.CurrentCardData, source.isPlayerCard);
                         Debug.Log("Perfectly Ultimate Great Moth: Invocado!");
                     }
                 );
             }
        }
    }

    void Effect_1418_PerformanceOfSword(CardDisplay source)
    {
        // This card is used to Ritual Summon "Skull Guardian".
        Debug.Log("Performance of Sword: Usada para Ritual Summon de Skull Guardian.");
    }

    // 1419 - Peten the Dark Clown
    void Effect_1419_PetenTheDarkClown(CardDisplay source)
    {
        // When sent to GY: Banish this card to SS Peten from hand/Deck.
        // Lógica implementada no OnCardSentToGraveyard.
        Debug.Log("Peten the Dark Clown: Efeito de gatilho no cemitério configurado.");
    }

    void Effect_1426_PharaohsTreasure(CardDisplay source)
    {
        GameManager.Instance.ReturnToDeck(source, false);
        GameManager.Instance.ShuffleDeck(source.isPlayerCard);
        CardEffectManager.Instance.pharaohsTreasureCards.Add(source.CurrentCardData);
        Debug.Log("Pharaoh's Treasure: Embaralhado no deck (Armadilhado!).");
    }

    void Effect_1428_PhoenixWingWindBlast(CardDisplay source)
    {
        // Discard 1 card to target 1 card your opponent controls; return that target to the top of the Deck.
        List<CardData> hand = GameManager.Instance.GetPlayerHandData();
        GameManager.Instance.OpenCardSelection(hand, "Selecione carta para descartar", (selectedDiscard) => {
            if (selectedDiscard != null)
            {
                GameManager.Instance.DiscardCard(GameManager.Instance.playerHand.Find(g => g.GetComponent<CardDisplay>().CurrentCardData == selectedDiscard).GetComponent<CardDisplay>());
        
                if (SpellTrapManager.Instance != null) {
                    SpellTrapManager.Instance.StartTargetSelection(
                    (t) => t.isOnField && !t.isPlayerCard,
                    (target) => {
                        GameManager.Instance.ReturnToDeck(target, true);
                    });
                }
            }
        });
    }

    void Effect_1429_PhysicalDouble(CardDisplay source)
    {
        if (BattleManager.Instance != null && BattleManager.Instance.currentAttacker != null) {
            CardDisplay attacker = BattleManager.Instance.currentAttacker;
            GameManager.Instance.SpawnToken(source.isPlayerCard, attacker.currentAtk, attacker.currentDef, "Mirage Token", attacker.CurrentCardData.level, attacker.CurrentCardData.race, attacker.CurrentCardData.attribute);
        }
    }

        // 1430 - Pikeru's Circle of Enchantment
    void Effect_1430_PikerusCircleOfEnchantment(CardDisplay source)
    {
        if (source.isPlayerCard) CardEffectManager.Instance.pikerusCircleActivePlayer = true;
        else CardEffectManager.Instance.pikerusCircleActiveOpponent = true;
        Debug.Log("Pikeru's Circle of Enchantment: Imunidade a dano de efeito ativada neste turno.");
    }

            void Effect_1431_PikerusSecondSight(CardDisplay source)
    {
        // Reveal all cards drawn by your opponent during your opponent's next Draw Phase.
        Debug.Log("Pikeru's Second Sight: As compras do oponente serão reveladas.");
        GameManager.Instance.revealOpponentDraw = true;
    }

    void Effect_1432_PinchHopper(CardDisplay source)
    {
        // When this card is sent from the field to the Graveyard: You can Special Summon 1 Insect-Type monster from your hand.
       Debug.Log("Pinch Hopper: SS 1 Insect-Type");
    }

    // 1433 - Pineapple Blast
    void Effect_1433_PineappleBlast(CardDisplay source)
    {
        int myCount = GameManager.Instance.GetMonsterCount(source.isPlayerCard);
        int oppCount = GameManager.Instance.GetMonsterCount(!source.isPlayerCard);
        if (oppCount > myCount)
        {
            int toDestroy = oppCount - myCount;
            List<CardDisplay> oppMonsters = new List<CardDisplay>();
            Transform[] oppZones = source.isPlayerCard ? GameManager.Instance.duelFieldUI.opponentMonsterZones : GameManager.Instance.duelFieldUI.playerMonsterZones;
            CollectMonsters(oppZones, oppMonsters);
            for (int i = 0; i < toDestroy; i++) {
                if (i < oppMonsters.Count) {
                    if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(oppMonsters[i]);
                    GameManager.Instance.SendToGraveyard(oppMonsters[i].CurrentCardData, !source.isPlayerCard);
                    Destroy(oppMonsters[i].gameObject);
                }
            }
        }
    }

    void Effect_1434_PiranhaArmy(CardDisplay source)
    {
        // This card can attack your opponent directly. If you use this effect, halve any battle damage you inflict to your opponent during that battle.
        Debug.Log("Piranha Army: double direct damage");
    }

    // 1435 - Pitch-Black Power Stone
    void Effect_1435_PitchBlackPowerStone(CardDisplay source)
    {
        // Activate: Place 3 Spell Counters.
        // Ignition: Move 1 counter to another card.
        if (source.spellCounters == 0 && !source.hasUsedEffectThisTurn) // Assumindo recém ativada
        if (SpellCounterManager.Instance.GetCount(source) == 0 && !source.hasUsedEffectThisTurn) // Assumindo recém ativada
        {
            source.AddSpellCounter(3);
            SpellCounterManager.Instance.AddCounter(source, 3);
            Debug.Log("Pitch-Black Power Stone: 3 contadores adicionados.");
        }
        else
        {
            // Lógica de mover contador (Ignição)
            if (source.spellCounters > 0 && SpellTrapManager.Instance != null)
            if (SpellCounterManager.Instance.GetCount(source) > 0 && SpellTrapManager.Instance != null)
            {
                SpellTrapManager.Instance.StartTargetSelection(
                    (t) => t.isOnField && t != source, // Alvo válido para receber contador
                    (target) => {
                        source.RemoveSpellCounter(1);
                        target.AddSpellCounter(1);
                        SpellCounterManager.Instance.RemoveCounter(source, 1);
                        SpellCounterManager.Instance.AddCounter(target, 1);
                        Debug.Log($"Pitch-Black Power Stone: Contador movido para {target.CurrentCardData.name}.");
                    }
                );
            }
        }
    }

    void Effect_1436_PitchBlackWarwolf(CardDisplay source)
    {
        // You can activate Trap Cards during the turn this card inflicts Battle Damage to your opponent.
        Debug.Log("Pitch-Black Warwolf: traps na battle phase");
    }

    void Effect_1437_PitchDarkDragon(CardDisplay source)
    {
       Debug.Log("Pitch-Dark Dragon: union"); 
    }

    // 1438 - Pixie Knight
    void Effect_1438_PixieKnight(CardDisplay source)
    {
        // Sent to GY by battle: Opponent selects 1 Spell in GY to top of Deck.
        // Lógica implementada no OnCardSentToGraveyard.
        Debug.Log("Pixie Knight: Efeito de reciclagem do oponente configurado.");
    }

    void Effect_1439_PoisonDrawFrog(CardDisplay source)
    {
        // When this card is sent from the field to the Graveyard: Draw 1 card.
        GameManager.Instance.DrawCard();
        Debug.Log("Poison Draw Frog: Compra 1");
    }

    void Effect_1440_PoisonFangs(CardDisplay source)
    {
        // If this card attacks a monster, increase the ATK of this card by 500 points during damage calculation only.
        // Lógica implementada no OnDamageCalculation.
    }

    void Effect_1441_PoisonMummy(CardDisplay source)
    {
        Effect_DirectDamage(source, 500);
    }

    void Effect_1442_PoisonOfTheOldMan(CardDisplay source)
    {
        if (UIManager.Instance != null) {
            UIManager.Instance.ShowConfirmation("Poison of the Old Man: Ganhar 1200 LP (Sim) ou Causar 800 de Dano (Não)?",
                () => { Effect_GainLP(source, 1200); },
                () => { Effect_DirectDamage(source, 800); }
            );
        }
    }

    void Effect_1443_PolePosition(CardDisplay source)
    {
        // The monster on the field with the highest ATK is unaffected by Spell Cards. If you control 2 or more monsters with the same ATK, apply this effect to all those monsters.
       Debug.Log("Pole Position: Monstro com maior ATK imune a magias (Lógica passiva no SpellTrapManager).");
       // Logic needs to be in SpellTrapManager.CanActivateCard or similar check
    }

    void Effect_1444_Polymerization(CardDisplay source)
    {
       // Inicia o processo de fusão
       GameManager.Instance.BeginFusionSummon(source);
    }

    void Effect_1445_PossessedDarkSoul(CardDisplay source)
    {
        if (source.isOnField)
        {
            GameManager.Instance.TributeCard(source);
            if (GameManager.Instance.duelFieldUI != null)
            {
                List<CardDisplay> toSteal = new List<CardDisplay>();
                Transform[] oppZones = source.isPlayerCard ? GameManager.Instance.duelFieldUI.opponentMonsterZones : GameManager.Instance.duelFieldUI.playerMonsterZones;
                foreach(var z in oppZones)
                {
                    if (z.childCount > 0)
                    {
                        var m = z.GetChild(0).GetComponent<CardDisplay>();
                        if (m != null && m.CurrentCardData.level <= 3) toSteal.Add(m);
                    }
                }
                foreach(var m in toSteal) GameManager.Instance.SwitchControl(m);
                Debug.Log($"Possessed Dark Soul: Roubou {toSteal.Count} monstro(s) de Nível 3 ou menor.");
            }
        }
    }

    void Effect_1446_PotOfGenerosity(CardDisplay source)
    {
        List<CardData> hand = GameManager.Instance.GetPlayerHandData();
        if (hand.Count >= 2) {
            GameManager.Instance.OpenCardMultiSelection(hand, "Retornar 2 cartas ao Deck", 2, 2, (selected) => {
                foreach (var c in selected) {
                    GameManager.Instance.RemoveCardFromHand(c, source.isPlayerCard);
                    GameManager.Instance.GetPlayerMainDeck().Add(c);
                }
                GameManager.Instance.ShuffleDeck(source.isPlayerCard);
            });
        }
    }

    void Effect_1447_PotOfGreed(CardDisplay source)
    {
        GameManager.Instance.DrawCard();
        GameManager.Instance.DrawCard();
        Debug.Log("Pot of Greed: Comprou 2");
    }
    // 1449 - Power Bond
    void Effect_1449_PowerBond(CardDisplay source)
    {
        // Fusion Summon Machine. ATK doubled. End Phase: Damage = Original ATK.
        List<CardData> extra = GameManager.Instance.GetPlayerExtraDeck();
        List<CardData> machines = extra.FindAll(c => c.type.Contains("Fusion") && c.race == "Machine");
        
        if (machines.Count > 0)
        {
            GameManager.Instance.OpenCardSelection(machines, "Power Bond: Fusão", (selected) => {
                var summoned = GameManager.Instance.SpecialSummonFromData(selected, source.isPlayerCard);
                if (summoned != null)
                {
                    summoned.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, selected.atk, source));
                    
                    if (source.isPlayerCard) CardEffectManager.Instance.powerBondDamageToPlayer += selected.atk;
                    else CardEffectManager.Instance.powerBondDamageToOpponent += selected.atk;
                }
                extra.Remove(selected);            });
        }
    }

    // 1450 - Power of Kaishin
    void Effect_1450_PowerOfKaishin(CardDisplay source)
    {
        Effect_Equip(source, 300, 300, "Aqua");
    }

    // 1452 - Precious Cards from Beyond
    void Effect_1452_PreciousCardsFromBeyond(CardDisplay source)
    {
        // If you Tribute Summon using 2 or more Tributes: Draw 2 cards.
        // Lógica implementada no OnSummonImpl.
        Debug.Log("Precious Cards from Beyond: Ativo.");
    }

    // 1453 - Premature Burial
    void Effect_1453_PrematureBurial(CardDisplay source)
    {
        // Pay 800 LP; SS monster from GY in Attack. Equip this card.
        if (Effect_PayLP(source, 800))
        {
            Effect_Revive(source, false); // false = apenas seu GY
            // Lógica de equipar e destruir se equip for destruído
        }
    }

    // 1454 - Prepare to Strike Back
    void Effect_1454_PrepareToStrikeBack(CardDisplay source)
    {
        if (BattleManager.Instance != null && BattleManager.Instance.currentAttacker != null)
        {
            CardDisplay attacker = BattleManager.Instance.currentAttacker;
            GameManager.Instance.TossCoin(1, (heads) => {
                if (heads == 1) {
                    Debug.Log("Prepare to Strike Back: Cara! Atacante muda para defesa.");
                    attacker.ChangePosition();
                } else {
                    Debug.Log("Prepare to Strike Back: Coroa! Atacante destruído.");
                    if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(attacker);
                    GameManager.Instance.SendToGraveyard(attacker.CurrentCardData, attacker.isPlayerCard);
                    Destroy(attacker.gameObject);
                }
            });
        }
    }

    // 1456 - Prickle Fairy
    void Effect_1456_PrickleFairy(CardDisplay source)
    {
        // Opponent cannot attack Insects. After damage calc, becomes Defense.
        Debug.Log("Prickle Fairy: Protege insetos.");
    }

    // 1457 - Primal Seed
    void Effect_1457_PrimalSeed(CardDisplay source)
    {
        // If BLS-EotB or CED-EotE on field: Add 2 banished cards to hand.
        bool hasChaos = GameManager.Instance.IsCardActiveOnField("0189") || GameManager.Instance.IsCardActiveOnField("0289");
        if (hasChaos)
        {
            List<CardData> banished = GameManager.Instance.GetPlayerRemoved();
            if (banished.Count > 0)
            {
                int max = Mathf.Min(2, banished.Count);
                GameManager.Instance.OpenCardMultiSelection(banished, "Recuperar Banidas", 1, max, (selected) => {
                    foreach(var c in selected)
                    {
                        banished.Remove(c);
                        GameManager.Instance.AddCardToHand(c, source.isPlayerCard);
                    }
                });
            }
        }
    }

    // 1458 - Princess of Tsurugi
    void Effect_1458_PrincessOfTsurugi(CardDisplay source)
    {
        // FLIP: 500 damage for each S/T opponent controls.
        int count = 0;
        if (GameManager.Instance.duelFieldUI != null)
        {
            foreach(var z in GameManager.Instance.duelFieldUI.opponentSpellZones) if(z.childCount > 0) count++;
            if (GameManager.Instance.duelFieldUI.opponentFieldSpell.childCount > 0) count++;
        }
        Effect_DirectDamage(source, count * 500);
    }

    // 1460 - Prohibition
    void Effect_1460_Prohibition(CardDisplay source)
    {
        if (GlobalCardSearchUI.Instance != null)
        {
            GlobalCardSearchUI.Instance.Show("Prohibition: Declare 1 carta", (declaredCard) => {
                if (declaredCard == null) return;
                
                GameManager.Instance.prohibitedCards.Add(declaredCard.name);
                Debug.Log($"Prohibition: '{declaredCard.name}' foi declarada e não pode ser usada.");
            });
        }
    }

    // 1461 - Protective Soul Ailin
    void Effect_1461_ProtectiveSoulAilin(CardDisplay source)
    {
        // Union for Indomitable Fighter Lei Lei.
        Effect_Union(source, "Indomitable Fighter Lei Lei", 0, 0);
    }

    // 1462 - Protector of the Sanctuary
    void Effect_1462_ProtectorOfTheSanctuary(CardDisplay source)
    {
        // Opponent cannot draw cards except during Draw Phase.
        Debug.Log("Protector of the Sanctuary: Bloqueio de compra.");
    }

        // 1465 - Pumpking the King of Ghosts
    void Effect_1465_PumpkingTheKingOfGhosts(CardDisplay source)
    {
        // If "Castle of Dark Illusions" is face-up: Gain 100 ATK/DEF.
        // Gains +100 more each Standby Phase (up to 4 turns). Lógica no OnPhaseStart.
        if (GameManager.Instance.IsCardActiveOnField("Castle of Dark Illusions") || GameManager.Instance.IsCardActiveOnField("1270"))
        {
            source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, 100, source));
            source.AddStatModifier(new StatModifier(StatModifier.StatType.DEF, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, 100, source));
            // Usa contadores para rastrear turnos (limite de 4)
            if (SpellCounterManager.Instance.GetCount(source) < 4)
                SpellCounterManager.Instance.AddCounter(source, 1);
            
            Debug.Log($"Pumpking: Buff aplicado. Turno {SpellCounterManager.Instance.GetCount(source)}/4.");
        }
    }

    // 1467 - Puppet Master
    void Effect_1467_PuppetMaster(CardDisplay source)
    {
        if (source.summonedThisTurn && source.isTributeSummoned)
        {
            List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
            List<CardData> fiends = gy.FindAll(c => c.race == "Fiend" && c.type.Contains("Monster"));
            
            if (fiends.Count >= 2 && Effect_PayLP(source, 2000))
            {
                GameManager.Instance.OpenCardMultiSelection(fiends, "Reviver 2 Fiends", 2, 2, (selected) => {
                    foreach(var c in selected) {
                        gy.Remove(c);
                        var summoned = GameManager.Instance.SpecialSummonFromData(c, source.isPlayerCard);
                        if (summoned != null) summoned.cannotAttackThisTurn = true;
                    }
                });
            }
        }
    }

    // 1468 - Pyramid Energy
    void Effect_1468_PyramidEnergy(CardDisplay source)
    {
        // Select 1 face-up monster; +200 ATK or +500 DEF.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && !t.isFlipped,
                (t) => {
                    // Simplificado: Dá os dois ou pede escolha (aqui dá ATK)
                    t.ModifyStats(200, 0);
                }
            );
        }
    }

    // 1469 - Pyramid Turtle
    void Effect_1469_PyramidTurtle(CardDisplay source)
    {
        // Destroyed by battle: SS Zombie DEF <= 2000 from Deck.
        Effect_SpecialSummonFromDeck(source, race: "Zombie", maxDef: 2000);
    }

    // 1470 - Pyramid of Light
    void Effect_1470_PyramidOfLight(CardDisplay source)
    {
        Debug.Log("Pyramid of Light: Vínculo com Esfinges ativo (Resolvido no OnCardLeavesField).");
    }

    // 1471 - Pyro Clock of Destiny
    void Effect_1471_PyroClockOfDestiny(CardDisplay source)
    {
        // Move turn count forward by 1.
        GameManager.Instance.turnCount++;
        Debug.Log("Pyro Clock of Destiny: Turno avançado em 1.");
    }

    // 1474 - Queen's Double
    void Effect_1474_QueensDouble(CardDisplay source)
    {
        source.canAttackDirectly = true;
    }

    // 1476 - Question
    void Effect_1476_Question(CardDisplay source)
    {
        // Opponent guesses bottom monster in GY. If wrong, SS it.
        // Simulating guess
        List<CardData> gy = GameManager.Instance.GetOpponentGraveyard(); // Opponent guesses YOUR GY? "your Graveyard".
        // Actually "When activating this card, your opponent cannot check cards in the Graveyard."
        // "Your opponent calls the name of the first monster found at the bottom of your Graveyard."
        
        List<CardData> myGY = GameManager.Instance.GetPlayerGraveyard();
        if (myGY.Count > 0)
        {
            CardData bottomMonster = null;
            // Find bottom-most monster (index 0 usually in List if added sequentially, or last? Assuming Add adds to end, index 0 is bottom)
            // Actually List.Add appends to end. So index 0 is oldest (bottom).
            foreach(var c in myGY) { if (c.type.Contains("Monster")) { bottomMonster = c; break; } }
            
            if (bottomMonster != null)
            {
                // Simulate guess (50/50)
                bool correct = Random.value > 0.5f;
                Debug.Log($"Question: Oponente chutou... {(correct ? "Correto" : "Errado")}!");
                
                if (correct)
                {
                    GameManager.Instance.RemoveFromPlay(bottomMonster, source.isPlayerCard);
                    myGY.Remove(bottomMonster);
                }
                else
                {
                    GameManager.Instance.SpecialSummonFromData(bottomMonster, source.isPlayerCard);
                    myGY.Remove(bottomMonster);
                }
            }
        }
    }

    // 1478 - Rafflesia Seduction
    void Effect_1478_RafflesiaSeduction(CardDisplay source)
    {
        // FLIP: Take control of 1 monster until End Phase.
        Effect_ChangeControl(source, true);
    }

    // 1479 - Raging Flame Sprite
    void Effect_1479_RagingFlameSprite(CardDisplay source)
    {
        // Direct attack. If successful, +1000 ATK.
        // Lógica implementada no OnDamageDealtImpl.
    }

    // 1480 - Raigeki
    void Effect_1480_Raigeki(CardDisplay source)
    {
        DestroyAllMonsters(true, false);
    }

    // 1481 - Raigeki Break
    void Effect_1481_RaigekiBreak(CardDisplay source)
    {
        // Discard 1 card; destroy 1 card on the field.
        List<CardData> hand = GameManager.Instance.GetPlayerHandData();
        if (hand.Count > 0)
        {
            GameManager.Instance.OpenCardSelection(hand, "Descarte 1 carta", (discarded) => {
                GameManager.Instance.DiscardCard(GameManager.Instance.playerHand.Find(g => g.GetComponent<CardDisplay>().CurrentCardData == discarded).GetComponent<CardDisplay>());
                
                if (SpellTrapManager.Instance != null)
                {
                    SpellTrapManager.Instance.StartTargetSelection(
                        (t) => t.isOnField,
                        (target) => {
                            if (DuelFXManager.Instance != null) DuelFXManager.Instance.PlayDestruction(target);
                            GameManager.Instance.SendToGraveyard(target.CurrentCardData, target.isPlayerCard);
                            Destroy(target.gameObject);
                        }
                    );
                }
            });
        }
    }

    // 1482 - Raimei
    void Effect_1482_Raimei(CardDisplay source)
    {
        Effect_DirectDamage(source, 300);
    }

    // 1483 - Rain of Mercy
    void Effect_1483_RainOfMercy(CardDisplay source)
    {
        GameManager.Instance.GainLifePoints(true, 1000);
        GameManager.Instance.GainLifePoints(false, 1000);
    }

    // 1484 - Rainbow Flower
    void Effect_1484_RainbowFlower(CardDisplay source)
    {
        source.canAttackDirectly = true;
        source.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, -400, source));
        source.AddStatModifier(new StatModifier(StatModifier.StatType.DEF, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, -400, source));
    }

    // 1486 - Raise Body Heat
    void Effect_1486_RaiseBodyHeat(CardDisplay source)
    {
        Effect_Equip(source, 300, 300, "Dinosaur");
    }

    // 1488 - Rare Metal Dragon
    void Effect_1488_RareMetalDragon(CardDisplay source)
    {
        Debug.Log("Rare Metal Dragon: Invocação restrita (Tratado no SummonManager).");
    }

    // 1489 - Rare Metalmorph
    void Effect_1489_RareMetalmorph(CardDisplay source)
    {
        // Target Machine: +500 ATK. Negate Spell targeting it once.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && t.CurrentCardData.race == "Machine",
                (t) => {
                    t.AddStatModifier(new StatModifier(StatModifier.StatType.ATK, StatModifier.ModifierType.Continuous, StatModifier.Operation.Add, 500, source));
                    GameManager.Instance.CreateCardLink(source, t, CardLink.LinkType.Equipment);
                    Debug.Log("Rare Metalmorph: Equipado. Protege contra 1 alvo.");
                }
            );
        }
    }

    // 1490 - Raregold Armor
    void Effect_1490_RaregoldArmor(CardDisplay source)
    {
        // Equip: Opponent must attack equipped monster.
        Effect_Equip(source, 0, 0);
    }

    // 1492 - Ray of Hope
    void Effect_1492_RayOfHope(CardDisplay source)
    {
        // Add 2 LIGHT monsters from GY to Deck.
        List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
        List<CardData> lights = gy.FindAll(c => c.attribute == "Light");
        
        if (lights.Count >= 2)
        {
            GameManager.Instance.OpenCardMultiSelection(lights, "Retornar 2 LIGHT", 2, 2, (selected) => {
                foreach(var c in selected)
                {
                    gy.Remove(c);
                    GameManager.Instance.GetPlayerMainDeck().Add(c);
                }
                GameManager.Instance.ShuffleDeck(source.isPlayerCard);
            });
        }
    }

    // 1493 - Re-Fusion
    void Effect_1493_ReFusion(CardDisplay source)
    {
        // Pay 800 LP; SS Fusion from GY and equip.
        if (Effect_PayLP(source, 800))
        {
            List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
            List<CardData> fusions = gy.FindAll(c => c.type.Contains("Fusion"));
            
            if (fusions.Count > 0)
            {
                GameManager.Instance.OpenCardSelection(fusions, "Reviver Fusão", (selected) => {
                    var summoned = GameManager.Instance.SpecialSummonFromData(selected, source.isPlayerCard);
                    gy.Remove(selected);
                    GameManager.Instance.CreateCardLink(source, summoned, CardLink.LinkType.Equipment);
                    Debug.Log($"Re-Fusion: Equipado em {selected.name}.");
                });
            }
        }
    }

    // 1494 - Ready for Intercepting
    void Effect_1494_ReadyForIntercepting(CardDisplay source)
    {
        // Target 1 Warrior/Spellcaster; change to face-down Defense.
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.StartTargetSelection(
                (t) => t.isOnField && (t.CurrentCardData.race == "Warrior" || t.CurrentCardData.race == "Spellcaster"),
                (t) => {
                    t.ChangePosition();
                    t.ShowBack();
                }
            );
        }
    }

    // 1495 - Really Eternal Rest
    void Effect_1495_ReallyEternalRest(CardDisplay source)
    {
        // Destroy all monsters equipped with Equip Cards.
        Effect_0610_EternalRest(source); // Mesma lógica
    }

    // 1496 - Reaper of the Cards
    void Effect_1496_ReaperOfTheCards(CardDisplay source)
    {
        // FLIP: Destroy 1 Trap.
        Effect_FlipDestroy(source, TargetType.Trap);
    }

    // 1497 - Reaper on the Nightmare
    void Effect_1497_ReaperOnTheNightmare(CardDisplay source)
    {
        source.canAttackDirectly = true;
    }

    // 1498 - Reasoning
    void Effect_1498_Reasoning(CardDisplay source)
    {
        List<string> levels = new List<string> { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" };
        if (MultipleChoiceUI.Instance != null)
        {
            MultipleChoiceUI.Instance.Show(levels, "Oponente: Declare um Nível", 1, 1, (selectedList) => {
                if (selectedList.Count > 0)
                {
                    int declaredLevel = int.Parse(selectedList[0]);
                    Debug.Log($"Reasoning: Oponente declarou Nível {declaredLevel}.");
                    
                    List<CardData> deck = source.isPlayerCard ? GameManager.Instance.GetPlayerMainDeck() : GameManager.Instance.GetOpponentMainDeck();
                    List<CardData> excavated = new List<CardData>();
                    CardData foundMonster = null;
                    
                    while(deck.Count > 0)
                    {
                        CardData c = deck[0];
                        deck.RemoveAt(0);
                        excavated.Add(c);
                        
                        if (c.type.Contains("Monster") && !c.type.Contains("Ritual") && !c.type.Contains("Fusion")) {
                            foundMonster = c; break;
                        }
                    }
                    
                    if (foundMonster != null) {
                        if (foundMonster.level == declaredLevel) { foreach(var c in excavated) GameManager.Instance.SendToGraveyard(c, source.isPlayerCard); }
                        else { GameManager.Instance.SpecialSummonFromData(foundMonster, source.isPlayerCard); excavated.Remove(foundMonster); foreach(var c in excavated) GameManager.Instance.SendToGraveyard(c, source.isPlayerCard); }
                    }
                    else { foreach(var c in excavated) GameManager.Instance.SendToGraveyard(c, source.isPlayerCard); }
                }
            });
        }
    }

    // 1499 - Reckless Greed
    void Effect_1499_RecklessGreed(CardDisplay source)
    {
        // Draw 2 cards. Skip next 2 Draw Phases.
        GameManager.Instance.DrawCard();
        GameManager.Instance.DrawCard();
        if (SpellTrapManager.Instance != null)
        {
            SpellTrapManager.Instance.RegisterSkipDraw();
            SpellTrapManager.Instance.RegisterSkipDraw();
        }
    }

    // 1500 - Recycle
    void Effect_1500_Recycle(CardDisplay source)
    {
        // Standby: Pay 300 LP; return 1 non-Monster from GY to bottom of Deck.
        if (Effect_PayLP(source, 300))
        {
            List<CardData> gy = GameManager.Instance.GetPlayerGraveyard();
            List<CardData> targets = gy.FindAll(c => !c.type.Contains("Monster"));
            
            if (targets.Count > 0)
            {
                GameManager.Instance.OpenCardSelection(targets, "Retornar ao Deck", (selected) => {
                    gy.Remove(selected);
                    GameManager.Instance.GetPlayerMainDeck().Add(selected); // Add to bottom
                });
            }
        }
    }
}